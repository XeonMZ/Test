import { PackageTrackingPage } from '@/features/live-trip/package-tracking-page';

export const metadata = {
  title: 'Lacak Paket — SJT Travel & Tour',
  description: 'Lacak posisi paket jastip Anda dengan kode resi. Tanpa perlu membuat akun.',
};

export default function Page() {
  return <PackageTrackingPage />;
}
