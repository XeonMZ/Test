import { EmailTemplatesPage } from '@/features/admin-owner/email-templates-page';
export const metadata = { title: 'Template Pesan — SJT' };
export default function Page() { return <EmailTemplatesPage />; }
