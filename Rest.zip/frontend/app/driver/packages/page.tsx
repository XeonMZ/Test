import { DriverPackagesPage } from '@/features/live-trip/driver-packages-page';

export const metadata = { title: 'Paket Saya — SJT Driver' };

export default function Page() {
  return <DriverPackagesPage />;
}
