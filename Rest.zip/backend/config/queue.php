<?php

// Beta safety switch: force the synchronous driver in non-production so a
// misconfigured worker can never silently swallow jobs during a beta. In
// production this yields to the real QUEUE_CONNECTION (redis on Railway).
$betaMode = (bool) env('STMS_BETA_MODE', true) && env('APP_ENV') !== 'production';

// INVARIANT: retry_after MUST be strictly greater than the queue worker's
// --timeout, otherwise Redis makes a still-running job "available" again and a
// second worker re-reserves and re-runs it before the first attempt finishes
// (double-processing, phantom retries, attempts climbing with no clear cause).
// The worker runs with --timeout=120 (see start.sh); default 180 leaves a safe
// margin. Overridable, but never allowed to fall to/under the worker timeout.
$retryAfter = max((int) env('QUEUE_RETRY_AFTER', 180), (int) env('QUEUE_TIMEOUT', 120) + 30);

return [
    'default' => $betaMode ? 'sync' : env('QUEUE_CONNECTION', 'sync'),

    'connections' => [
        'sync' => ['driver' => 'sync'],
        'database' => ['driver' => 'database', 'table' => 'jobs', 'queue' => 'default', 'retry_after' => $retryAfter],
        'redis' => [
            'driver' => 'redis',
            'connection' => 'default',
            'queue' => env('REDIS_QUEUE', 'default'),
            'retry_after' => $retryAfter,
            // null keeps the historical sleep-based polling (safe with predis,
            // whose read_write_timeout would otherwise abort a long BLPOP).
            'block_for' => env('REDIS_QUEUE_BLOCK_FOR'),
        ],
    ],

    // Per-job retry policy for the transactional email pipeline. Read at runtime
    // via config() (NOT env(), which returns null once config is cached), so the
    // values are honoured on the worker with zero hardcoding. Backoff is a
    // comma-separated seconds list; tries counts the final attempt.
    'transactional_email' => [
        'tries' => max(1, (int) env('MAIL_QUEUE_TRIES', 5)),
        'backoff' => array_values(array_filter(
            array_map(
                static fn ($v): int => (int) trim((string) $v),
                explode(',', (string) env('MAIL_QUEUE_BACKOFF', '60,300,900,3600'))
            ),
            static fn (int $v): bool => $v > 0
        )),
        'log_channel' => env('MAIL_QUEUE_LOG_CHANNEL'),
    ],

    'failed' => ['driver' => 'database-uuids', 'database' => env('DB_CONNECTION', 'mysql'), 'table' => 'failed_jobs'],
];
