<?php

// Honor an explicitly configured MAIL_MAILER; default to the safe 'log'
// transport when none is set.
return [
    'default' => env('MAIL_MAILER', 'log'),

    'mailers' => [
        'resend' => [
            'transport' => 'resend',
        ],

        'smtp' => [
            'transport' => 'smtp',
            'host' => env('MAIL_HOST', '127.0.0.1'),
            'port' => env('MAIL_PORT', 2525),
            'encryption' => env('MAIL_ENCRYPTION'),
            'username' => env('MAIL_USERNAME'),
            'password' => env('MAIL_PASSWORD'),

            // Without an explicit timeout, Symfony Mailer falls back to PHP's
            // default_socket_timeout (60s). An unreachable / silent SMTP host
            // then blocks the worker for a full minute before throwing — the
            // "runs, then FAILs ~1 min later" symptom. Bounding it here makes
            // the TransportException surface fast and deterministically, well
            // under the 120s worker timeout, so retries/backoff kick in cleanly.
            'timeout' => (float) env('MAIL_TIMEOUT', 30),

            // Some MTAs reject a missing/garbage EHLO name. Default to the app
            // host so the greeting is always well-formed.
            'local_domain' => env('MAIL_EHLO_DOMAIN', parse_url((string) env('APP_URL', 'http://localhost'), PHP_URL_HOST) ?: 'localhost'),
        ],

        'log' => [
            'transport' => 'log',
            'channel' => env('MAIL_LOG_CHANNEL'),
        ],
    ],

    'from' => [
        'address' => env('MAIL_FROM_ADDRESS', 'mail@sekawanjayatrans.com'),
        'name' => env('MAIL_FROM_NAME', 'SJT Travel'),
    ],
];
