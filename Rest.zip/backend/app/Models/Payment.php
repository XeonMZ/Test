<?php

declare(strict_types=1);

namespace App\Models;

use App\Models\Concerns\HasUuid;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

final class Payment extends Model
{
    use HasFactory, HasUuid, SoftDeletes;

    protected $guarded = ['id'];
    protected $hidden = ['deleted_at'];
    protected $casts = ['metadata'=>'array','settings'=>'array','value'=>'array','starts_at'=>'datetime','ends_at'=>'datetime','departure_at'=>'datetime','arrival_at'=>'datetime','is_active'=>'boolean','enabled'=>'boolean','amount'=>'decimal:2','base_fare'=>'decimal:2','gateway_payload'=>'array','expires_at'=>'datetime','paid_at'=>'datetime','failed_at'=>'datetime'];

    /** Surfaced on every serialised payment so the admin UI can show the refundable base without recomputing fee math client-side. */
    protected $appends = ['refund_preview'];

    public function booking(): BelongsTo { return $this->belongsTo(Booking::class); }

    /**
     * How much of this payment is refundable (base fare) versus withheld
     * (admin fee + tax), from the one authoritative calculator.
     *
     * Lets the owner — who does the bank transfer by hand — see the exact
     * amount to send back before confirming, instead of the fee-inclusive total.
     *
     * @return array{charged: int, refundable: int, withheld: int}
     */
    public function getRefundPreviewAttribute(): array
    {
        $charged = (int) round((float) $this->amount);
        $refundable = \App\Support\Payments\RefundCalculator::refundableBase($charged, is_array($this->gateway_payload) ? $this->gateway_payload : []);

        return [
            'charged' => $charged,
            'refundable' => $refundable,
            'withheld' => max(0, $charged - $refundable),
        ];
    }
}
