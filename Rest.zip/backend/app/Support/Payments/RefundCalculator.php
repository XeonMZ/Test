<?php

declare(strict_types=1);

namespace App\Support\Payments;

/**
 * Works out how much of a payment is refundable.
 *
 * Company policy: a refund returns the base fare only. The admin fee is a
 * service charge for processing the booking — the work of taking the payment
 * was done and does not un-happen on cancellation — and tax already remitted is
 * not the company's to give back. So neither is refundable, and both must be
 * subtracted from the amount actually charged.
 *
 * The base fare is read from the pricing breakdown that PaymentService persists
 * into `gateway_payload['pricing']` at charge time. That stored figure is
 * authoritative: recomputing the fee here from current settings would return
 * the wrong number for any payment taken before a fee change, refunding against
 * a rule that did not apply when the customer actually paid.
 *
 * Every branch is written to fail *safe*. "Safe" for a refund means never
 * returning more than was charged — an over-refund is money out the door — so
 * when the breakdown is missing or malformed the amount charged is used as-is
 * rather than guessed upward.
 */
final class RefundCalculator
{
    /**
     * The refundable base fare for one payment.
     *
     * @param  int    $amountCharged     What the customer was actually charged (payment.amount).
     * @param  array<string, mixed>  $gatewayPayload  The payment's stored gateway payload.
     * @return int    Refundable amount in the same integer rupiah unit as $amountCharged.
     */
    public static function refundableBase(int $amountCharged, array $gatewayPayload): int
    {
        $pricing = self::pricing($gatewayPayload);

        // No stored breakdown — e.g. a payment taken before fees existed, or a
        // record whose payload was never populated. There is no fee to strip,
        // so the whole charge is the base fare. Never inflate it.
        if ($pricing === null) {
            return max(0, $amountCharged);
        }

        $baseFare = self::num($pricing['base_fare'] ?? null);
        $adminFee = self::num($pricing['admin_fee'] ?? null);
        $tax = self::num($pricing['tax'] ?? null);

        // The full-price total (base + fee + tax), reconstructed from the parts.
        // The stored `total` key is NOT used for this: on a DP it holds the
        // scaled-down charge and on a settlement it holds only the remaining
        // balance, while base_fare/admin_fee/tax are always recorded at full
        // price. Rebuilding from the parts gives one stable denominator that is
        // the same for the DP and its settlement, which is what makes the base
        // share consistent across both.
        $fullTotal = $baseFare !== null ? $baseFare + ($adminFee ?? 0) + ($tax ?? 0) : null;

        // The fee is stripped proportionally: refund the same fraction of the
        // charge that the base fare is of the full price. This is correct for
        // every payment shape —
        //   · full payment  → charged == fullTotal, fraction of base is exact;
        //   · down payment  → charged is a slice of fullTotal, base slice = same
        //                     fraction, so the DP's own fee share is withheld;
        //   · settlement     → charged is the remaining slice, and the same base
        //                     fraction withholds exactly the remaining fee share.
        // In all three the withheld amount is the fee+tax portion of *this*
        // payment, never more.
        if ($baseFare !== null && $fullTotal !== null && $fullTotal > 0) {
            $refundable = (int) round($amountCharged * ($baseFare / $fullTotal));

            return max(0, min($refundable, $amountCharged));
        }

        // Fallback when base_fare is missing but fee/tax are known: subtract
        // them directly. A safe backstop; PaymentService always records
        // base_fare, so this is reached only for malformed payloads.
        if ($adminFee !== null || $tax !== null) {
            $refundable = (int) round($amountCharged - ($adminFee ?? 0) - ($tax ?? 0));

            return max(0, min($refundable, $amountCharged));
        }

        // Breakdown present but empty of usable numbers — refund the charge
        // rather than guess a fee.
        return max(0, $amountCharged);
    }

    /**
     * The non-refundable portion (admin fee + tax), for display.
     *
     * Always exactly `amountCharged - refundableBase`, so the two figures a
     * customer sees — refunded and withheld — reconcile to the total to the
     * rupiah, with no rounding gap between them.
     */
    public static function nonRefundable(int $amountCharged, array $gatewayPayload): int
    {
        return max(0, $amountCharged - self::refundableBase($amountCharged, $gatewayPayload));
    }

    /**
     * Pull the pricing breakdown out of the gateway payload.
     *
     * @param  array<string, mixed>  $gatewayPayload
     * @return array<string, mixed>|null
     */
    private static function pricing(array $gatewayPayload): ?array
    {
        $pricing = $gatewayPayload['pricing'] ?? null;

        return is_array($pricing) ? $pricing : null;
    }

    /** A numeric field as float, or null when it is missing or non-numeric. */
    private static function num(mixed $value): ?float
    {
        return is_numeric($value) ? (float) $value : null;
    }
}
