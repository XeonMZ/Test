<?php

declare(strict_types=1);

namespace App\Support\Uploads;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * The single place an uploaded image becomes a file on disk.
 *
 * Both upload endpoints (CMS media and Settings media) route through here, so
 * a hardening fix cannot land on one and miss the other.
 *
 * The threat this defends against is not "someone uploads a .php file" —
 * Laravel's `mimes:` rule already stops the obvious version. It is the polyglot:
 * a file that is a genuinely valid JPEG *and* contains PHP source, appended
 * after the image data or hidden in an EXIF comment. `getimagesize()` says
 * image, the extension says .jpg, the MIME says image/jpeg — and if the web
 * server can be persuaded to execute anything in the storage directory, the
 * payload runs.
 *
 * Two independent defences, because either one alone can be worked around:
 *
 *   1. **Re-encode.** The uploaded bytes are decoded to a pixel buffer and a
 *      brand-new file is written from that buffer. Pixels survive; everything
 *      else — appended payloads, EXIF blocks, ICC profiles, trailing archives —
 *      does not. It cannot be smuggled through because it is never copied.
 *
 *   2. **Deny execution at the directory.** Re-encoding assumes GD decoded the
 *      file the same way the attacker expected. The drop files written by
 *      `protectStorageDirectory()` mean that even a crafted file that survives
 *      is served as bytes rather than run.
 *
 * Stripping EXIF is a privacy fix as much as a security one: photos taken on a
 * phone carry GPS coordinates, and an operator uploading a picture of a pickup
 * point would otherwise publish the exact location — and time — it was taken.
 */
final class ImageUploadService
{
    /** Types accepted, mapped to the extension actually written to disk. */
    private const ALLOWED = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    /**
     * Dimension ceiling, checked before any pixels are allocated.
     *
     * A 64000×64000 PNG compresses to a few hundred kilobytes and expands to
     * roughly 12 GB in memory — a decompression bomb that takes the process
     * down without any file ever being written. The check happens on the
     * header, before decoding.
     */
    private const MAX_DIMENSION = 10000;

    /** Longest edge kept after re-encoding. Beyond this is waste on any screen. */
    private const MAX_STORED_EDGE = 2400;

    private const JPEG_QUALITY = 86;
    private const WEBP_QUALITY = 86;

    /**
     * Validate, sanitise and store one uploaded image.
     *
     * @return array{path: string, url: string, width: int, height: int}
     *
     * @throws ValidationException with a message an operator can act on
     */
    public function store(UploadedFile $file, string $directory, string $field = 'image'): array
    {
        $this->assertUploadSucceeded($file, $field);

        // The real type, read from the file's own bytes. The browser-supplied
        // Content-Type and the filename extension are both attacker-controlled
        // and are never consulted.
        $info = @getimagesize($file->getRealPath());
        if ($info === false) {
            $this->fail($field, 'Berkas ini bukan gambar yang bisa dibaca. Gunakan JPG, PNG, atau WEBP.');
        }

        [$width, $height] = [(int) $info[0], (int) $info[1]];
        $mime = strtolower((string) ($info['mime'] ?? ''));

        if (! isset(self::ALLOWED[$mime])) {
            $this->fail($field, 'Format gambar tidak didukung. Gunakan JPG, PNG, atau WEBP.');
        }
        if ($width < 1 || $height < 1 || $width > self::MAX_DIMENSION || $height > self::MAX_DIMENSION) {
            $this->fail($field, 'Ukuran dimensi gambar tidak wajar. Maksimal '.self::MAX_DIMENSION.' piksel per sisi.');
        }

        $extension = self::ALLOWED[$mime];
        $filename = Str::lower(Str::random(40)).'.'.$extension;
        $relativePath = trim($directory, '/').'/'.$filename;

        $bytes = $this->reencode($file->getRealPath(), $mime, $width, $height);

        if ($bytes === null) {
            // GD unavailable or refused the file. Rather than fall back to
            // copying the original bytes — which is exactly the thing this
            // service exists to avoid — the upload is refused.
            Log::warning('Image upload rejected: re-encode unavailable or failed.', [
                'mime' => $mime,
                'directory' => $directory,
                'gd_loaded' => extension_loaded('gd'),
            ]);
            $this->fail($field, 'Gambar tidak dapat diproses di server. Coba simpan ulang gambar lalu unggah lagi.');
        }

        Storage::disk('public')->put($relativePath, $bytes, ['visibility' => 'public']);
        $this->protectStorageDirectory($directory);

        $stored = @getimagesize(Storage::disk('public')->path($relativePath));

        return [
            'path' => $relativePath,
            'url' => asset('storage/'.$relativePath),
            'width' => (int) ($stored[0] ?? $width),
            'height' => (int) ($stored[1] ?? $height),
        ];
    }

    /**
     * Turn PHP's upload error codes into something an operator can act on.
     *
     * This is the fix for "gagal mengunggah foto" with no further explanation.
     * When a file exceeds `upload_max_filesize`, PHP hands Laravel an entry
     * with an error code and no content — the framework's `required` rule then
     * reports the field as missing, so the operator is told the image is
     * required while looking straight at the image they just picked. The real
     * cause is a server limit they cannot see and the message never mentions.
     */
    private function assertUploadSucceeded(UploadedFile $file, string $field): void
    {
        if ($file->isValid()) {
            return;
        }

        $limit = self::serverLimitMb();

        $this->fail($field, match ($file->getError()) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => "Ukuran foto melebihi batas server ({$limit} MB). Kecilkan resolusi foto lalu coba lagi.",
            UPLOAD_ERR_PARTIAL => 'Unggahan terputus di tengah jalan. Periksa koneksi lalu coba lagi.',
            UPLOAD_ERR_NO_FILE => 'Tidak ada berkas yang terkirim.',
            UPLOAD_ERR_NO_TMP_DIR, UPLOAD_ERR_CANT_WRITE => 'Server tidak dapat menyimpan berkas sementara. Hubungi administrator.',
            default => 'Unggahan gagal diproses server. Coba lagi.',
        });
    }

    /**
     * The smaller of PHP's two upload ceilings, in whole megabytes.
     *
     * Both apply, and hosting panels routinely set them to different values —
     * quoting the larger one sends the operator to shrink a file that was never
     * going to fit anyway.
     */
    public static function serverLimitMb(): int
    {
        $upload = self::iniBytes((string) ini_get('upload_max_filesize'));
        $post = self::iniBytes((string) ini_get('post_max_size'));

        $effective = min($upload > 0 ? $upload : PHP_INT_MAX, $post > 0 ? $post : PHP_INT_MAX);

        return $effective === PHP_INT_MAX ? 8 : max(1, (int) floor($effective / 1048576));
    }

    /** Parse a php.ini shorthand size ("8M", "512K", "1G") into bytes. */
    private static function iniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '') {
            return 0;
        }

        $unit = strtolower(substr($value, -1));
        $number = (int) $value;

        return match ($unit) {
            'g' => $number * 1073741824,
            'm' => $number * 1048576,
            'k' => $number * 1024,
            default => $number,
        };
    }

    /**
     * Decode to pixels and write a fresh file.
     *
     * Returns null when GD is missing or the decode fails, so the caller can
     * refuse rather than silently store unsanitised bytes.
     */
    private function reencode(string $sourcePath, string $mime, int $width, int $height): ?string
    {
        if (! extension_loaded('gd')) {
            return null;
        }

        $image = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($sourcePath),
            'image/png' => @imagecreatefrompng($sourcePath),
            'image/webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($sourcePath) : false,
            default => false,
        };

        if (! $image) {
            return null;
        }

        try {
            $image = $this->downscale($image, $width, $height, $mime);

            ob_start();
            $ok = match ($mime) {
                'image/jpeg' => imagejpeg($image, null, self::JPEG_QUALITY),
                // PNG compression 6 keeps transparency without the CPU cost of 9.
                'image/png' => imagepng($image, null, 6),
                'image/webp' => function_exists('imagewebp') && imagewebp($image, null, self::WEBP_QUALITY),
                default => false,
            };
            $bytes = (string) ob_get_clean();

            return $ok && $bytes !== '' ? $bytes : null;
        } finally {
            // GD handles are freed on every path, including the failure ones —
            // an upload endpoint that leaks a few megabytes per rejected file
            // is a slow denial of service.
            if ($image instanceof \GdImage) {
                imagedestroy($image);
            }
        }
    }

    /** Shrink to MAX_STORED_EDGE, preserving aspect ratio and transparency. */
    private function downscale(\GdImage $image, int $width, int $height, string $mime): \GdImage
    {
        $longest = max($width, $height);
        if ($longest <= self::MAX_STORED_EDGE) {
            return $image;
        }

        $ratio = self::MAX_STORED_EDGE / $longest;
        $targetWidth = max(1, (int) round($width * $ratio));
        $targetHeight = max(1, (int) round($height * $ratio));

        $canvas = imagecreatetruecolor($targetWidth, $targetHeight);

        if ($mime === 'image/png' || $mime === 'image/webp') {
            // Without this a transparent logo comes back with a black box
            // behind it — truecolor canvases start opaque black.
            imagealphablending($canvas, false);
            imagesavealpha($canvas, true);
            imagefill($canvas, 0, 0, imagecolorallocatealpha($canvas, 0, 0, 0, 127));
        }

        imagecopyresampled($canvas, $image, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);
        imagedestroy($image);

        return $canvas;
    }

    /**
     * Drop deny-execution files beside the uploads.
     *
     * Belt and braces behind the re-encode. Written idempotently on each upload
     * rather than once at deploy, because the storage directory is frequently
     * recreated (a fresh `storage:link`, a container rebuild, a restored
     * backup) and a protection that only exists if someone remembered to run a
     * command is a protection that eventually is not there.
     *
     * Covers Apache (`.htaccess`) and IIS (`web.config`). Nginx ignores both —
     * see the note in the docs for the location block that server needs.
     */
    private function protectStorageDirectory(string $directory): void
    {
        $disk = Storage::disk('public');

        $files = [
            '.htaccess' => "# Uploaded media only — never execute anything here.\nphp_flag engine off\nAddType text/plain .php .php3 .php4 .php5 .php7 .php8 .phtml .phar .htaccess\n<FilesMatch \"\\.(php|php3|php4|php5|php7|php8|phtml|phar|cgi|pl|py|sh|htaccess)$\">\n    Require all denied\n</FilesMatch>\n",
            'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration>\n  <system.webServer>\n    <handlers accessPolicy=\"Read\" />\n  </system.webServer>\n</configuration>\n",
        ];

        foreach ([trim($directory, '/'), ''] as $target) {
            foreach ($files as $name => $contents) {
                $path = $target === '' ? $name : $target.'/'.$name;
                if (! $disk->exists($path)) {
                    $disk->put($path, $contents);
                }
            }
        }
    }

    /** @throws ValidationException */
    private function fail(string $field, string $message): never
    {
        throw ValidationException::withMessages([$field => $message]);
    }
}
