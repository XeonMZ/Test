<?php

declare(strict_types=1);

namespace App\Support\Mail;

use App\Models\SystemSetting;

/**
 * CMS-editable email templates. Admin/owner store overrides in the
 * `email_templates` System Setting (JSON keyed by type):
 *
 *   {"payment_success": {"subject": "...", "heading": "Terima kasih, {name}!",
 *                        "intro": "..."}}
 *
 * `resolve()` merges overrides over the code defaults and substitutes
 * {placeholders} from the given context. Overrides are plain text only —
 * Blade escapes them on render, so no markup/script can be injected into
 * the emails through the CMS.
 */
final class EmailTemplate
{
    public const TYPES = [
        'verify_email', 'reset_password', 'payment_success', 'payment_failed',
        'booking_cancelled', 'payment_refunded', 'package_booking', 'dp_settlement_reminder',
    ];

    /**
     * The placeholders each template type may use, for the editor's reference
     * panel. Kept here beside the substitution logic so the documented list and
     * the values actually passed at send time cannot drift apart — a
     * placeholder shown to an operator that never gets a value is worse than no
     * documentation, because they will build a sentence around it.
     *
     * Every type gets the brand/company set; the auth types add {code} and its
     * companions; the transactional types add the order fields relevant to them.
     *
     * @var array<string, list<string>>
     */
    public const PLACEHOLDERS = [
        'verify_email' => ['name', 'code', 'expiry_minutes', 'company', 'support_email', 'request_ip', 'requested_at'],
        'reset_password' => ['name', 'code', 'expiry_minutes', 'company', 'support_email', 'request_ip', 'requested_at'],
        'payment_success' => ['name', 'code', 'amount', 'item', 'company', 'support_email'],
        'payment_failed' => ['name', 'code', 'amount', 'item', 'company', 'support_email'],
        'booking_cancelled' => ['name', 'code', 'item', 'company', 'support_email'],
        'payment_refunded' => ['name', 'code', 'amount', 'item', 'company', 'support_email'],
        'package_booking' => ['name', 'code', 'amount', 'item', 'company', 'support_email'],
        'dp_settlement_reminder' => ['name', 'code', 'amount', 'outstanding', 'item', 'due_date', 'company', 'support_email'],
    ];

    /**
     * Human labels for the placeholders, for the editor's reference chips.
     *
     * @var array<string, string>
     */
    public const PLACEHOLDER_LABELS = [
        'name' => 'Nama penerima',
        'code' => 'Kode (OTP / kode booking / kode transaksi)',
        'expiry_minutes' => 'Masa berlaku kode (menit)',
        'amount' => 'Nominal pembayaran',
        'outstanding' => 'Sisa tagihan',
        'item' => 'Nama layanan / paket',
        'due_date' => 'Batas waktu pelunasan',
        'company' => 'Nama perusahaan',
        'support_email' => 'Email dukungan',
        'request_ip' => 'Alamat IP peminta',
        'requested_at' => 'Waktu permintaan',
    ];

    /**
     * @param array{subject: string, heading: string, intro: string} $defaults
     * @param array<string, string|int|float|null> $context
     * @return array{subject: string, heading: string, intro: string}
     */
    public static function resolve(string $type, array $defaults, array $context = []): array
    {
        $all = self::all();
        $override = is_array($all[$type] ?? null) ? $all[$type] : [];

        // The brand/company fields are always available, so an operator can
        // sign any template without the caller having to remember to pass them.
        $context += [
            'company' => (string) config('branding.name', 'SJT Travel'),
            'support_email' => (string) config('branding.support_email', 'mail@sekawanjayatrans.com'),
        ];

        $out = [];
        foreach (['subject', 'heading', 'intro'] as $field) {
            $raw = trim((string) ($override[$field] ?? '')) ?: $defaults[$field];
            $out[$field] = self::render($raw, $context);
        }
        return $out;
    }

    /**
     * Substitute `{placeholder}` tokens.
     *
     * A placeholder with no value collapses and the surrounding whitespace and
     * dangling punctuation is tidied, so an incomplete record sends clean prose
     * rather than "kode  telah" with a hole in it. An *unknown* placeholder —
     * one the operator typed that this type does not supply — is left visible
     * rather than silently deleted, so the mistake shows up in the preview
     * instead of vanishing into a sent email.
     *
     * @param array<string, string|int|float|null> $context
     */
    public static function render(string $template, array $context = []): string
    {
        $replacements = [];
        foreach ($context as $key => $value) {
            $replacements['{'.$key.'}'] = trim((string) ($value ?? ''));
        }

        $out = strtr($template, $replacements);
        // Only tidy where a *known* placeholder resolved to empty; unknown
        // tokens still contain braces and are left exactly as typed.
        $out = (string) preg_replace('/\s+([,.:;!?])/', '$1', $out);
        $out = (string) preg_replace('/[ \t]{2,}/', ' ', $out);

        return trim($out);
    }

    /** @return array<string, mixed> */
    public static function all(): array
    {
        $value = SystemSetting::query()->where('key', 'email_templates')->value('value');
        if (is_array($value)) {
            return isset($value['value']) && is_array($value['value']) ? $value['value'] : $value;
        }
        $decoded = json_decode((string) $value, true);
        return is_array($decoded) ? $decoded : [];
    }
}
