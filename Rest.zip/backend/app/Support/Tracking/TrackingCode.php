<?php

declare(strict_types=1);

namespace App\Support\Tracking;

use Illuminate\Database\Eloquent\Model;

/**
 * Receipt codes for packages a customer will read off a phone screen, a paper
 * slip, or a WhatsApp message and type back in.
 *
 * Two properties matter, and they pull against each other:
 *
 * 1. Hard to enumerate. The code is the only credential on a public tracking
 *    page — anyone holding it sees where the package is — so the keyspace has
 *    to be large enough that guessing is pointless. Eight characters over a
 *    32-symbol alphabet is 2^40, about 1.1 trillion codes. Paired with the
 *    lookup cooldown, an attacker gets roughly one guess every two minutes;
 *    finding a single live package would take longer than the universe has
 *    been around.
 *
 * 2. Possible to type correctly. This is where the previous generator fell
 *    down: `Str::upper(Str::random(8))` can emit `0` and `O`, `1` and `I`,
 *    which a human reading a printed slip cannot tell apart. Every such
 *    collision becomes a failed lookup, and failed lookups are exactly what
 *    the cooldown punishes — so ambiguous characters turn an anti-abuse
 *    measure into a trap for honest customers.
 *
 * The alphabet below is Crockford's Base32: digits and uppercase letters with
 * I, L, O and U removed (U is dropped because its absence makes accidental
 * profanity far less likely). Input is normalised on the way in, so a customer
 * who types `O` where the code has `0`, or lowercases the whole thing, still
 * lands on their package.
 */
final class TrackingCode
{
    /** Crockford Base32 — no I, L, O, U. */
    private const ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

    private const LENGTH = 8;

    /**
     * A fresh code in `PREFIX-XXXX-XXXX` form, guaranteed unused.
     *
     * Uniqueness is confirmed against the table rather than assumed from the
     * keyspace: a collision is astronomically unlikely, but `code` carries a
     * unique index, and a collision that slipped through would surface as a
     * failed insert on a customer's order rather than as a retry here.
     */
    public static function generate(string $modelClass, string $column = 'code', string $prefix = 'JST'): string
    {
        for ($attempt = 0; $attempt < 10; $attempt++) {
            $code = $prefix.'-'.self::randomBlock().'-'.self::randomBlock();

            /** @var class-string<Model> $modelClass */
            if (! $modelClass::query()->where($column, $code)->withoutGlobalScopes()->exists()) {
                return $code;
            }
        }

        // Ten collisions in a row against a 2^40 keyspace means something is
        // wrong with the random source, not with luck. Failing loudly beats
        // handing out a code that may already belong to someone else.
        throw new \RuntimeException('Tidak dapat membuat kode resi yang unik.');
    }

    /**
     * Fold user input into canonical form: uppercase, no stray characters,
     * single dashes, trimmed. Returns null when nothing usable is left.
     */
    public static function normalise(string $input): ?string
    {
        $value = strtoupper(trim($input));
        // Keep only characters that can appear in a code, dashes included.
        $value = preg_replace('/[^A-Z0-9-]/', '', $value) ?? '';
        // Collapse any dash run and trim the ends, so "JST--ABC-" behaves.
        $value = trim((string) preg_replace('/-+/', '-', $value), '-');

        return $value === '' ? null : $value;
    }

    /**
     * Every stored code the input could plausibly mean.
     *
     * Codes minted here cannot contain O, I or L, so folding those to 0 and 1
     * recovers a customer who typed what the glyph looked like. But codes
     * issued *before* this generator existed came from `Str::random()` and can
     * legitimately contain all three — folding them unconditionally would make
     * every one of those packages untrackable. So both readings are returned
     * and the caller matches against either: the fold helps new codes without
     * breaking old ones.
     *
     * @return list<string>
     */
    public static function candidates(string $input): array
    {
        $exact = self::normalise($input);
        if ($exact === null) {
            return [];
        }

        $folded = strtr($exact, ['O' => '0', 'I' => '1', 'L' => '1']);

        return $folded === $exact ? [$exact] : [$exact, $folded];
    }

    private static function randomBlock(): string
    {
        $alphabet = self::ALPHABET;
        $max = strlen($alphabet) - 1;
        $block = '';

        for ($i = 0; $i < self::LENGTH / 2; $i++) {
            // random_int() is the CSPRNG. mt_rand()/Str::random()'s underlying
            // pool would be predictable enough to matter for a credential.
            $block .= $alphabet[random_int(0, $max)];
        }

        return $block;
    }
}
