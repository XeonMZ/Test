<?php

declare(strict_types=1);

namespace App\Support\Messaging;

use App\Models\SystemSetting;

/**
 * CMS-editable WhatsApp message templates.
 *
 * Deliberately built the same way as App\Support\Mail\EmailTemplate: code
 * defaults, per-type overrides in one System Setting, `{placeholder}`
 * substitution on resolve. An operator who has learned to edit one editor has
 * learned both.
 *
 * The templates are resolved **server-side** and handed to the driver's app
 * already filled in, rather than shipping the raw templates to the client to
 * substitute. Two reasons: the client would need its own copy of the
 * substitution rules, which is how the two drift apart; and a driver on a
 * stale bundle would keep sending last month's wording after an operator
 * changed it.
 *
 * Copy is plain text. It ends up in a `wa.me?text=` query string, URL-encoded
 * at the point of use, so nothing here can break out into the link itself.
 */
final class WhatsAppTemplate
{
    /**
     * Message types, their defaults, and the placeholders each one may use.
     *
     * Passenger templates speak in booking terms (booking code, seats, pickup
     * point); package templates speak in delivery terms (receipt code, item,
     * sender and receiver). A driver messaging a parcel recipient about a
     * "booking" would read as though the company had lost track of what it was
     * carrying.
     */
    public const DEFAULTS = [
        'passenger_contact' => [
            'label' => 'Hubungi Penumpang',
            'description' => 'Dikirim driver saat menghubungi penumpang lewat WhatsApp dari manifest.',
            'body' => 'Halo {customer_name}, saya {driver_name} dari {company}. Saya driver untuk booking {booking_code} Anda hari ini. Titik jemput: {pickup}. Mohon konfirmasinya, terima kasih.',
            'placeholders' => ['customer_name', 'driver_name', 'company', 'booking_code', 'pickup', 'drop', 'seats', 'vehicle'],
        ],
        'passenger_arriving' => [
            'label' => 'Penumpang — Segera Tiba',
            'description' => 'Dipakai saat driver mengabari penumpang bahwa ia hampir sampai di titik jemput.',
            'body' => 'Halo {customer_name}, saya {driver_name} dari {company}. Saya sudah dekat dengan titik jemput {pickup} untuk booking {booking_code}. Mohon bersiap ya, terima kasih.',
            'placeholders' => ['customer_name', 'driver_name', 'company', 'booking_code', 'pickup', 'drop', 'seats', 'vehicle'],
        ],
        'package_sender' => [
            'label' => 'Hubungi Pengirim Paket',
            'description' => 'Dikirim driver saat akan mengambil paket dari pengirim.',
            'body' => 'Halo {sender_name}, saya {driver_name} dari {company}. Saya akan mengambil paket {item_name} dengan resi {package_code} di {pickup}. Mohon disiapkan ya, terima kasih.',
            'placeholders' => ['sender_name', 'receiver_name', 'driver_name', 'company', 'package_code', 'item_name', 'pickup', 'drop'],
        ],
        'package_receiver' => [
            'label' => 'Hubungi Penerima Paket',
            'description' => 'Dikirim driver saat akan mengantar paket ke penerima.',
            'body' => 'Halo {receiver_name}, saya {driver_name} dari {company}. Saya sedang mengantar paket {item_name} dengan resi {package_code} ke {drop}. Mohon konfirmasinya, terima kasih.',
            'placeholders' => ['sender_name', 'receiver_name', 'driver_name', 'company', 'package_code', 'item_name', 'pickup', 'drop'],
        ],
    ];

    private const SETTING_KEY = 'whatsapp_templates';

    /** Longest message an operator may save, and the cap applied on render. */
    public const MAX_LENGTH = 1000;

    /**
     * One filled-in message, ready to hand to `wa.me`.
     *
     * @param array<string, string|int|float|null> $context
     */
    public static function resolve(string $type, array $context = []): string
    {
        $default = self::DEFAULTS[$type]['body'] ?? '';
        $overrides = self::all();
        $raw = trim((string) ($overrides[$type] ?? '')) ?: $default;

        return self::render($raw, $context);
    }

    /**
     * Substitute `{placeholder}` values.
     *
     * A placeholder with no value collapses to nothing and the sentence around
     * it is tidied: a template that says "booking {booking_code} Anda" would
     * otherwise send "booking  Anda" with a hole in it when a record is
     * incomplete, which looks like a broken system to the customer receiving
     * it. Unknown placeholders are left untouched so an operator sees their
     * typo rather than silently losing the word.
     *
     * @param array<string, string|int|float|null> $context
     */
    public static function render(string $template, array $context = []): string
    {
        $replacements = [];
        foreach ($context as $key => $value) {
            $replacements['{'.$key.'}'] = trim((string) ($value ?? ''));
        }

        $out = strtr($template, $replacements);
        // Collapse the whitespace and stray punctuation an empty value leaves.
        $out = (string) preg_replace('/\s+([,.])/', '$1', $out);
        $out = (string) preg_replace('/\s{2,}/', ' ', $out);

        return mb_substr(trim($out), 0, self::MAX_LENGTH);
    }

    /**
     * Stored overrides, keyed by type.
     *
     * @return array<string, string>
     */
    public static function all(): array
    {
        $value = SystemSetting::query()->where('key', self::SETTING_KEY)->value('value');

        if (is_array($value)) {
            $value = isset($value['value']) && is_array($value['value']) ? $value['value'] : $value;
        } else {
            $decoded = json_decode((string) $value, true);
            $value = is_array($decoded) ? $decoded : [];
        }

        $out = [];
        foreach ($value as $type => $body) {
            if (is_string($body) && trim($body) !== '') {
                $out[$type] = $body;
            }
        }

        return $out;
    }

    /** @param array<string, string> $templates */
    public static function put(array $templates): void
    {
        SystemSetting::updateOrCreate(['key' => self::SETTING_KEY], ['value' => $templates, 'is_public' => false]);
    }

    /** The company name templates greet customers with. */
    public static function companyName(): string
    {
        $value = SystemSetting::query()->where('key', 'company_name')->value('value');
        $name = is_array($value) ? ($value['value'] ?? null) : $value;

        return trim((string) ($name ?? '')) ?: 'SJT Travel & Tour';
    }
}
