<?php

declare(strict_types=1);

namespace App\Jobs;

use App\Support\Observability\CorrelationContext;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Throwable;

/**
 * Sends one transactional email asynchronously.
 *
 * Retry with exponential backoff (config queue.transactional_email.backoff,
 * default 1m -> 5m -> 15m -> 1h). The audit row (email_logs) is kept current on
 * EVERY attempt — the latest error is written even while retries remain, so an
 * operator watching the row can see *why* a send is failing without waiting for
 * the terminal attempt. On terminal failure failed() flips status to 'failed'
 * and Laravel records the job in failed_jobs.
 *
 * Every attempt (success or failure) emits a structured log line to the default
 * channel (stderr on Railway) carrying the job UUID, recipient, mailer,
 * resolved transport, attempt number, execution time, correlation id and — on
 * failure — the full exception with stack trace. Nothing fails silently.
 */
final class SendTransactionalEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /** Max attempts (incl. the final one). Sourced from config at dispatch. */
    public int $tries;

    /** @var array<int, int> Exponential backoff in seconds, sourced from config. */
    public array $backoff;

    public function __construct(
        private readonly string $logUuid,
        private readonly string $toEmail,
        private readonly Mailable $mailable,
    ) {
        // Read the retry policy from config (never env() — that returns null once
        // config is cached). Resolved here at dispatch time and serialized into
        // the job payload, so the worker honours it without hardcoded values.
        $this->tries = max(1, (int) config('queue.transactional_email.tries', 5));

        $backoff = config('queue.transactional_email.backoff', [60, 300, 900, 3600]);
        $this->backoff = is_array($backoff) && $backoff !== []
            ? array_map('intval', array_values($backoff))
            : [60, 300, 900, 3600];
    }

    public function handle(): void
    {
        $startedAt = microtime(true);
        $this->ensureCorrelationId();

        DB::table('email_logs')->where('uuid', $this->logUuid)->increment('attempts');

        $mailer = (string) config('mail.default');
        $attempt = $this->attempts();

        try {
            Mail::to($this->toEmail)->send($this->mailable);
        } catch (Throwable $e) {
            // Persist the latest error on the audit row on every attempt. Status
            // stays 'queued' while retries remain (failed() will flip it to
            // 'failed' once exhausted); the error column no longer sits empty
            // during the retry window.
            DB::table('email_logs')->where('uuid', $this->logUuid)->update([
                'error' => $this->formatError($e),
                'updated_at' => now(),
            ]);

            $this->logEvent('error', 'attempt_failed', $mailer, $attempt, $this->elapsedMs($startedAt), $e);

            // Rethrow so the framework applies backoff / retries and, once tries
            // are exhausted, records the job in failed_jobs and calls failed().
            throw $e;
        }

        DB::table('email_logs')->where('uuid', $this->logUuid)->update([
            'status' => 'sent',
            'sent_at' => now(),
            'error' => null,
            'updated_at' => now(),
        ]);

        $this->logEvent('info', 'sent', $mailer, $attempt, $this->elapsedMs($startedAt));
    }

    public function failed(Throwable $exception): void
    {
        $this->ensureCorrelationId();

        DB::table('email_logs')->where('uuid', $this->logUuid)->update([
            'status' => 'failed',
            'error' => $this->formatError($exception),
            'updated_at' => now(),
        ]);

        $this->logEvent('critical', 'failed_permanently', (string) config('mail.default'), $this->attempts(), null, $exception);
    }

    private function ensureCorrelationId(): void
    {
        if (CorrelationContext::correlationId() === 'not-started') {
            CorrelationContext::start();
        }
    }

    private function elapsedMs(float $startedAt): float
    {
        return round((microtime(true) - $startedAt) * 1000, 2);
    }

    private function formatError(Throwable $e): string
    {
        return mb_substr(sprintf('[%s] %s', $e::class, $e->getMessage()), 0, 2000);
    }

    /** Best-effort transport identity for the log (e.g. "smtp://host:port"). */
    private function resolveTransport(string $mailer): string
    {
        try {
            return (string) Mail::mailer($mailer)->getSymfonyTransport();
        } catch (Throwable) {
            return $mailer;
        }
    }

    private function logEvent(string $level, string $event, string $mailer, int $attempt, ?float $executionMs, ?Throwable $e = null): void
    {
        $context = [
            'event' => 'transactional_email.'.$event,
            'job_uuid' => $this->job?->uuid(),
            'email_log_uuid' => $this->logUuid,
            'recipient' => $this->toEmail,
            'mailable' => $this->mailable::class,
            'mailer' => $mailer,
            'transport' => $this->resolveTransport($mailer),
            'attempt' => $attempt,
            'max_tries' => $this->tries,
            'execution_ms' => $executionMs,
            'correlation_id' => CorrelationContext::correlationId(),
        ];

        if ($e !== null) {
            $context['exception_class'] = $e::class;
            $context['exception_code'] = $e->getCode();
            $context['exception_file'] = $e->getFile().':'.$e->getLine();
            // Guaranteed full trace as text, independent of the log formatter.
            $context['exception_trace'] = $e->getTraceAsString();
            // The Throwable itself, so structured sinks / Monolog can render it too.
            $context['exception'] = $e;
        }

        $channel = config('queue.transactional_email.log_channel') ?: config('logging.default');

        Log::channel((string) $channel)->log($level, 'mail.transactional_email.'.$event, $context);
    }
}
