<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\AuditTrail;
use App\Models\SystemSetting;
use App\Support\Audit\RequestContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Admin-fee and tax configuration.
 *
 * The calculation already lives in PaymentService, which reads
 * `payment_admin_fees` (per-method rules) and `payment_tax_percent` from
 * System Settings and applies them at the single charge choke point. What was
 * missing was a safe way to *set* them: the generic key/value settings form
 * stores a raw string, and `payment_admin_fees` is nested JSON. An operator
 * hand-editing that JSON is one missing brace away from either a fee of zero
 * (revenue silently lost) or a malformed rule that the payment path skips.
 *
 * This endpoint owns that structure. It reads and writes the exact shape
 * PaymentService expects, and — because this is money — it validates every
 * field rather than trusting a JSON blob:
 *
 *   - a percent fee cannot exceed 100 (a typo'd "200%" would triple a charge);
 *   - a fixed fee cannot be negative (a negative fee pays the customer to book);
 *   - values are coerced to numbers, so "4.000" pasted with a thousands dot
 *     cannot become the string "4" or NaN downstream.
 *
 * The methods mirror PaymentService's normalisation: bank_transfer, snap,
 * qris. `default` is the fallback applied to any method without its own rule.
 */
final class PaymentFeeController extends Controller
{
    /** Payment methods a rule can target, plus the catch-all. */
    private const METHODS = ['default', 'bank_transfer', 'snap', 'qris'];

    private const FEE_KEY = 'payment_admin_fees';
    private const TAX_KEY = 'payment_tax_percent';

    /** A fixed fee above this is almost certainly a typo, so it is rejected. */
    private const MAX_FIXED_FEE = 10_000_000;

    public function show(): JsonResponse
    {
        $fees = $this->readJson(self::FEE_KEY);

        $rules = [];
        foreach (self::METHODS as $method) {
            $rule = is_array($fees[$method] ?? null) ? $fees[$method] : null;
            $rules[$method] = [
                'type' => ($rule['type'] ?? 'fixed') === 'percent' ? 'percent' : 'fixed',
                'value' => (float) ($rule['value'] ?? 0),
                // A method with no stored rule, or a zero value, is "off" —
                // surfaced explicitly so the UI can show a clear toggle rather
                // than an ambiguous zero.
                'enabled' => is_array($rule) && (float) ($rule['value'] ?? 0) > 0,
            ];
        }

        return response()->json(['data' => [
            'methods' => self::METHODS,
            'rules' => $rules,
            'tax_percent' => (float) ($this->readScalar(self::TAX_KEY) ?? 0),
        ]]);
    }

    public function update(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'tax_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'rules' => ['required', 'array'],
            'rules.*.type' => ['required', 'in:fixed,percent'],
            'rules.*.value' => ['required', 'numeric', 'min:0'],
            'rules.*.enabled' => ['required', 'boolean'],
        ], [
            'rules.*.value.min' => 'Biaya tidak boleh negatif.',
            'tax_percent.max' => 'Pajak tidak masuk akal — maksimal 100%.',
        ]);

        // Build the exact structure PaymentService reads. A disabled rule, or a
        // zero value, is omitted entirely rather than stored as {value:0} — a
        // rule that is not there and a rule that charges nothing behave the
        // same in the payment path, and the smaller object is easier to reason
        // about when read back.
        $fees = [];
        foreach ($validated['rules'] as $method => $rule) {
            if (! in_array($method, self::METHODS, true)) {
                continue; // ignore any method the client invented
            }
            $value = round((float) $rule['value'], $rule['type'] === 'percent' ? 2 : 0);

            if (! $rule['enabled'] || $value <= 0) {
                continue;
            }
            // Guardrails that a numeric validator alone cannot express, because
            // the ceiling depends on the fee type.
            if ($rule['type'] === 'percent' && $value > 100) {
                return $this->reject("Biaya persen untuk {$method} tidak boleh lebih dari 100%.");
            }
            if ($rule['type'] === 'fixed' && $value > self::MAX_FIXED_FEE) {
                return $this->reject("Biaya tetap untuk {$method} terlalu besar.");
            }

            $fees[$method] = ['type' => $rule['type'], 'value' => $value];
        }

        $taxPercent = round((float) $validated['tax_percent'], 2);

        $beforeFees = $this->readJson(self::FEE_KEY);
        $beforeTax = $this->readScalar(self::TAX_KEY);

        // Fees are operational config, not a customer-facing value, so the
        // setting stays non-public: the amounts reach customers only as the
        // computed total in their invoice, never as a raw rule the client
        // could read and depend on.
        SystemSetting::updateOrCreate(['key' => self::FEE_KEY], ['value' => $fees, 'is_public' => false]);
        SystemSetting::updateOrCreate(['key' => self::TAX_KEY], ['value' => $taxPercent, 'is_public' => false]);

        $meta = RequestContext::enrich($request, [
            'before' => ['fees' => $beforeFees, 'tax' => $beforeTax],
            'after' => ['fees' => $fees, 'tax' => $taxPercent],
        ]);
        AuditTrail::record('setting.payment_fees_updated', 'SystemSetting', 'user', (string) $request->user()?->id, $meta);
        ActivityLog::create(['action' => 'setting.payment_fees_updated', 'subject_type' => 'SystemSetting', 'subject_id' => null, 'metadata' => $meta]);

        return response()->json(['data' => ['saved' => true, 'rules' => $fees, 'tax_percent' => $taxPercent]]);
    }

    /**
     * Preview the charge on a sample amount and method.
     *
     * Computed by the SAME arithmetic PaymentService uses, so what the operator
     * sees here is what a customer will actually be charged — the point of a
     * preview is defeated if it is a second, approximate implementation.
     */
    public function preview(Request $request): JsonResponse
    {
        $data = $request->validate([
            'amount' => ['required', 'numeric', 'min:0'],
            'method' => ['required', 'string'],
        ]);

        $amount = (float) $data['amount'];
        $method = $data['method'];

        $fees = $this->readJson(self::FEE_KEY);
        $rule = $fees[$method] ?? $fees['default'] ?? null;

        $adminFee = 0.0;
        if (is_array($rule)) {
            $adminFee = ($rule['type'] ?? 'fixed') === 'percent'
                ? round($amount * ((float) ($rule['value'] ?? 0)) / 100)
                : (float) ($rule['value'] ?? 0);
        }

        $taxPercent = (float) ($this->readScalar(self::TAX_KEY) ?? 0);
        $tax = round($amount * $taxPercent / 100);
        $total = (int) round($amount + $adminFee + $tax);

        return response()->json(['data' => [
            'base_fare' => $amount,
            'admin_fee' => $adminFee,
            'tax_percent' => $taxPercent,
            'tax' => $tax,
            'total' => $total,
        ]]);
    }

    /** @return array<string, mixed> */
    private function readJson(string $key): array
    {
        $value = SystemSetting::query()->where('key', $key)->value('value');
        if (is_array($value)) {
            return isset($value['value']) && is_array($value['value']) ? $value['value'] : $value;
        }
        $decoded = json_decode((string) $value, true);

        return is_array($decoded) ? $decoded : [];
    }

    private function readScalar(string $key): mixed
    {
        $value = SystemSetting::query()->where('key', $key)->value('value');

        return is_array($value) ? ($value['value'] ?? null) : $value;
    }

    private function reject(string $message): JsonResponse
    {
        return response()->json(['success' => false, 'message' => $message, 'data' => []], 422);
    }
}
