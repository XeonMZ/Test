<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Middleware\PublicTrackingCooldown;
use App\Models\JastipOrder;
use App\Models\Trip;
use App\Support\Tracking\TrackingCode;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Public package tracking — "cek resi".
 *
 * The flow is split in two on purpose:
 *
 *   POST /track/package        code → package + a session token   (cooldown)
 *   GET  /track/package/{token} token → live position             (no cooldown)
 *
 * Putting the live position behind a token instead of behind the code is what
 * lets both requirements hold at once. The cooldown exists to make guessing
 * codes pointless, and it only bites on a miss; live tracking needs to poll
 * every few seconds, which a per-request cooldown would forbid outright. One
 * successful lookup buys a session, and the session — not the receipt code —
 * is what the map polls.
 *
 * It also keeps the code out of the browser URL and history, which matters for
 * a credential that anyone holding can use.
 */
final class PackageTrackingController extends Controller
{
    /** How long one successful lookup stays good for. */
    private const SESSION_MINUTES = 30;

    /** Statuses whose packages are still moving and worth a live map. */
    private const IN_TRANSIT = ['assigned', 'picked_up'];

    /**
     * Mirrors LiveTripController::TRIP_ACTIVE. Duplicated rather than imported
     * because that constant is private to a module controller; if the trip
     * lifecycle gains a state, both lists need it.
     */
    private const TRIP_ACTIVE = ['started', 'pickup', 'boarding', 'on_route', 'drop_off'];

    /**
     * Look up a package by receipt code.
     *
     * A miss is reported with the FAILED_HEADER so the cooldown middleware
     * knows to start the window; the body deliberately says nothing about
     * *why* it missed. Distinguishing "no such code" from "code exists but is
     * cancelled" would let an attacker map the keyspace without ever seeing a
     * package.
     */
    public function lookup(Request $request): JsonResponse
    {
        $data = $request->validate([
            'code' => 'required|string|min:4|max:40',
        ]);

        $candidates = TrackingCode::candidates($data['code']);

        $order = $candidates === []
            ? null
            : JastipOrder::query()
                ->with(['route:id,code,origin,destination', 'driver:id,user_id', 'driver.user:id,name'])
                ->whereIn('code', $candidates)
                ->first();

        if ($order === null) {
            return response()
                ->json([
                    'success' => false,
                    'message' => 'Kode resi tidak ditemukan. Periksa kembali kode pada bukti pengiriman Anda.',
                    'data' => [],
                ], 404)
                ->header(PublicTrackingCooldown::FAILED_HEADER, '1');
        }

        $token = Str::random(48);
        Cache::put("tracking:session:{$token}", $order->id, now()->addMinutes(self::SESSION_MINUTES));

        return response()->json(['data' => [
            'token' => $token,
            'expires_in_minutes' => self::SESSION_MINUTES,
            'package' => $this->packagePayload($order),
            'live' => $this->livePayload($order),
        ]]);
    }

    /**
     * Live state for an already-resolved package.
     *
     * Cheap by design — this is the endpoint the map polls.
     */
    public function live(string $token): JsonResponse
    {
        $orderId = Cache::get('tracking:session:'.$token);

        if ($orderId === null) {
            return response()->json([
                'success' => false,
                'message' => 'Sesi pelacakan sudah berakhir. Masukkan kode resi Anda kembali.',
                'data' => [],
            ], 419);
        }

        $order = JastipOrder::query()
            ->with(['route:id,code,origin,destination', 'driver:id,user_id', 'driver.user:id,name'])
            ->find($orderId);

        if ($order === null) {
            Cache::forget('tracking:session:'.$token);

            return response()->json(['success' => false, 'message' => 'Paket tidak ditemukan.', 'data' => []], 404);
        }

        return response()->json(['data' => [
            'package' => $this->packagePayload($order),
            'live' => $this->livePayload($order),
        ]]);
    }

    /**
     * What the customer is allowed to know about their package.
     *
     * Deliberately narrow: no fee, no other packages, no driver phone number,
     * and only the driver's display name. Anyone with the code can see this,
     * and a receipt code is a weak credential to hang personal data on.
     */
    private function packagePayload(JastipOrder $order): array
    {
        return [
            'code' => $order->code,
            'item_name' => $order->item_name,
            'status' => $order->status,
            'sender_name' => $order->sender_name,
            'receiver_name' => $order->receiver_name,
            'pickup' => [
                'label' => $order->pickup_label,
                'lat' => $order->pickup_lat !== null ? (float) $order->pickup_lat : null,
                'lng' => $order->pickup_lng !== null ? (float) $order->pickup_lng : null,
            ],
            'drop' => [
                'label' => $order->drop_label,
                'lat' => $order->drop_lat !== null ? (float) $order->drop_lat : null,
                'lng' => $order->drop_lng !== null ? (float) $order->drop_lng : null,
            ],
            'route' => $order->route?->only(['origin', 'destination']),
            'driver_name' => $order->driver?->user?->name,
            'picked_up_at' => $order->picked_up_at,
            'delivered_at' => $order->delivered_at,
            'created_at' => $order->created_at,
        ];
    }

    /**
     * The driver's position, when there is genuinely one to show.
     *
     * A delivered or cancelled package reports `active: false` rather than the
     * driver's current whereabouts: once the parcel is handed over, its receipt
     * code stops being a licence to watch that driver drive around for the rest
     * of the day.
     */
    private function livePayload(JastipOrder $order): array
    {
        if (! in_array($order->status, self::IN_TRANSIT, true) || $order->driver_id === null) {
            return ['active' => false, 'location' => null, 'path' => [], 'trip_id' => null];
        }

        $trip = Trip::query()
            ->where('driver_id', $order->driver_id)
            ->whereIn('status', self::TRIP_ACTIVE)
            ->latest('id')
            ->first();

        if ($trip === null) {
            return ['active' => false, 'location' => null, 'path' => [], 'trip_id' => null];
        }

        $row = DB::table('driver_locations')->where('trip_id', $trip->id)->orderByDesc('id')->first();

        return [
            'active' => true,
            'trip_id' => (int) $trip->id,
            'location' => $row ? [
                'lat' => (float) $row->latitude,
                'lng' => (float) $row->longitude,
                'recorded_at' => (string) $row->recorded_at,
                'speed' => $row->speed !== null ? (float) $row->speed : null,
                'heading' => $row->heading !== null ? (float) $row->heading : null,
            ] : null,
            // Same reasoning as the customer trip view: a long breadcrumb
            // reconstructs every address the courier has stopped at today, and
            // whoever holds this receipt code is entitled to exactly one of
            // them. Enough points to animate the marker, not to map a round.
            'path' => DB::table('driver_locations')
                ->where('trip_id', $trip->id)
                ->orderByDesc('id')
                ->limit(10)
                ->get(['latitude', 'longitude'])
                ->reverse()
                ->values()
                ->map(fn ($r): array => ['lat' => (float) $r->latitude, 'lng' => (float) $r->longitude])
                ->all(),
        ];
    }
}
