<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\AuditTrail;
use App\Models\CmsSection;
use App\Models\CmsVersion;
use App\Models\TourPackage;
use App\Support\Audit\RequestContext;
use App\Support\Uploads\ImageUploadService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Tour Package CMS + Home/Content CMS.
 * Admin & owner manage everything through the UI; customers consume the
 * public catalog endpoints (published content only). Every mutation lands in
 * the existing audit trail.
 */
final class CmsController extends Controller
{
    // ------------------------- Tour Packages -------------------------

    public function packages(Request $request): JsonResponse
    {
        $q = TourPackage::query()->orderBy('sort_order')->orderByDesc('id');
        if ($search = $request->string('search')->toString()) {
            $q->where(fn ($x) => $x->where('name', 'like', "%{$search}%")->orWhere('destination', 'like', "%{$search}%"));
        }
        if ($status = $request->string('status')->toString()) {
            $q->where('status', $status);
        }
        return response()->json(['data' => $q->paginate(min(100, max(1, (int) $request->query('per_page', '20'))))]);
    }

    public function packageStore(Request $request): JsonResponse
    {
        $package = TourPackage::create($this->packageData($request));
        $this->audit($request, 'cms.package_created', ['id' => $package->id, 'name' => $package->name]);
        return response()->json(['data' => $package], 201);
    }

    public function packageUpdate(Request $request, string $id): JsonResponse
    {
        $package = TourPackage::findOrFail($id);
        $data = $this->packageData($request, (int) $id, partial: true);
        $before = $package->only(array_keys($data));
        $package->update($data);
        $this->audit($request, 'cms.package_updated', ['id' => $package->id, 'before' => $before]);
        return response()->json(['data' => $package->fresh()]);
    }

    public function packageDestroy(Request $request, string $id): JsonResponse
    {
        $package = TourPackage::findOrFail($id);
        $package->delete();
        $this->audit($request, 'cms.package_deleted', ['id' => (int) $id, 'name' => $package->name]);
        return response()->json(['data' => ['deleted' => true]]);
    }

    /** @return array<string, mixed> */
    private function packageData(Request $request, ?int $ignoreId = null, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';
        return $request->validate([
            'name' => "{$req}|string|max:150",
            'description' => 'sometimes|nullable|string|max:8000',
            'destination' => 'sometimes|nullable|string|max:150',
            'duration_days' => 'sometimes|integer|min:1|max:60',
            'facilities' => 'sometimes|nullable|array',
            'facilities.*' => 'string|max:120',
            // Itinerary is a list of days, each {day, title, detail}. The shape
            // is validated rather than accepted as a free-form array: the
            // customer detail page renders these fields directly, and a row
            // saved with a string where an object belongs would break that page
            // for every visitor until an editor noticed.
            'itinerary' => 'sometimes|nullable|array|max:60',
            'itinerary.*' => 'array',
            'itinerary.*.day' => 'required_with:itinerary|integer|min:1|max:365',
            'itinerary.*.title' => 'sometimes|nullable|string|max:150',
            'itinerary.*.detail' => 'sometimes|nullable|string|max:2000',
            'price' => "{$req}|numeric|min:0",
            'capacity' => 'sometimes|integer|min:0|max:1000',
            'cover_path' => 'sometimes|nullable|string|max:255',
            'gallery' => 'sometimes|nullable|array',
            'gallery.*' => 'string|max:255',
            'status' => 'sometimes|in:active,inactive',
            'badge' => 'sometimes|nullable|string|max:32',
            'is_featured' => 'sometimes|boolean',
            'is_recommended' => 'sometimes|boolean',
            'is_best_seller' => 'sometimes|boolean',
            'is_promo' => 'sometimes|boolean',
            'sort_order' => 'sometimes|integer|min:0|max:9999',
        ]);
    }

    // --------------------------- CMS Sections ---------------------------

    public function sections(Request $request): JsonResponse
    {
        $q = CmsSection::query()->orderBy('section_type')->orderBy('sort_order');
        if ($type = $request->string('type')->toString()) {
            $q->where('section_type', $type);
        }
        return response()->json(['data' => $q->paginate(min(200, max(1, (int) $request->query('per_page', '100'))))]);
    }

    public function sectionStore(Request $request): JsonResponse
    {
        $section = CmsSection::create($this->sectionData($request));
        $this->audit($request, 'cms.section_created', ['id' => $section->id, 'type' => $section->section_type]);
        return response()->json(['data' => $section], 201);
    }

    public function sectionUpdate(Request $request, string $id): JsonResponse
    {
        $section = CmsSection::findOrFail($id);
        $data = $this->sectionData($request, partial: true);
        $before = $section->only(array_keys($data));
        $section->update($data);
        $this->audit($request, 'cms.section_updated', ['id' => $section->id, 'type' => $section->section_type, 'before' => $before]);
        return response()->json(['data' => $section->fresh()]);
    }

    public function sectionDestroy(Request $request, string $id): JsonResponse
    {
        $section = CmsSection::findOrFail($id);
        $section->delete();
        $this->audit($request, 'cms.section_deleted', ['id' => (int) $id, 'type' => $section->section_type]);
        return response()->json(['data' => ['deleted' => true]]);
    }

    /** @return array<string, mixed> */
    private function sectionData(Request $request, bool $partial = false): array
    {
        $req = $partial ? 'sometimes' : 'required';
        return $request->validate([
            'section_type' => "{$req}|in:".implode(',', CmsSection::TYPES),
            'title' => 'sometimes|nullable|string|max:200',
            'body' => 'sometimes|nullable|string|max:8000',
            'image_path' => 'sometimes|nullable|string|max:255',
            'link' => 'sometimes|nullable|string|max:255',
            'sort_order' => 'sometimes|integer|min:0|max:9999',
            'is_active' => 'sometimes|boolean',
            'publish_start' => 'sometimes|nullable|date',
            'publish_end' => 'sometimes|nullable|date|after_or_equal:publish_start',
            'metadata' => 'sometimes|nullable|array',
        ]);
    }

    // ------------------------- Public catalog -------------------------

    /** Published packages, optionally filtered by section flag. */
    /**
     * GET /catalog/tour-packages
     *
     * The search/filter/sort surface behind the public package listing.
     *
     * Every predicate runs in SQL rather than being applied to a fetched
     * collection: the listing is paginated, so filtering client-side would
     * mean "page 1 of everything, minus the rows that did not match" — a
     * result count that lies and pages that shrink as the user walks them.
     *
     * `filter` (the curated flags) is kept for the rails on the landing view;
     * it composes with the new predicates instead of replacing them.
     */
    public function catalogPackages(Request $request): JsonResponse
    {
        // Aggregates come from the database, not from loading every rating:
        // a package with thousands of reviews must not cost thousands of rows
        // to render one card.
        $q = TourPackage::query()
            ->withCount('ratings')
            ->withAvg('ratings', 'stars')
            ->where('status', 'active');

        match ($request->string('filter')->toString()) {
            'featured' => $q->where('is_featured', true),
            'recommended' => $q->where('is_recommended', true),
            'best_seller' => $q->where('is_best_seller', true),
            'promo' => $q->where('is_promo', true),
            default => null,
        };

        // Free-text search across the three fields a traveller actually types.
        if ($term = trim($request->string('q')->toString())) {
            $like = '%'.$this->escapeLike($term).'%';
            $q->where(function ($x) use ($like): void {
                $x->where('name', 'like', $like)
                    ->orWhere('destination', 'like', $like)
                    ->orWhere('description', 'like', $like);
            });
        }

        if ($destination = trim($request->string('destination')->toString())) {
            $q->where('destination', $destination);
        }

        // Price and duration bounds are independent: sending only one is valid.
        if ($request->filled('min_price')) {
            $q->where('price', '>=', max(0, (float) $request->query('min_price')));
        }
        if ($request->filled('max_price')) {
            $q->where('price', '<=', max(0, (float) $request->query('max_price')));
        }
        if ($request->filled('min_days')) {
            $q->where('duration_days', '>=', max(1, (int) $request->query('min_days')));
        }
        if ($request->filled('max_days')) {
            $q->where('duration_days', '<=', max(1, (int) $request->query('max_days')));
        }

        // Facilities are a JSON array. A LIKE against the encoded column is
        // used deliberately in place of whereJsonContains(): the latter needs
        // the JSON1 extension, which is not guaranteed on every SQLite build
        // this app is installed on, and a silent driver error here would empty
        // the catalogue rather than widen it.
        foreach (array_slice((array) $request->query('facilities', []), 0, 10) as $facility) {
            if (! is_string($facility) || trim($facility) === '') {
                continue;
            }
            // Quoted so the match is a whole array element: searching for
            // "Hotel" must not also match a package offering "Hotel Transit".
            $encoded = json_encode(trim($facility), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($encoded === false) {
                continue;
            }
            $q->where('facilities', 'like', '%'.$this->escapeLike($encoded).'%');
        }

        // Minimum rating compares against the same average the card prints.
        // Expressed as a correlated subquery rather than HAVING on the
        // withAvg() alias, which the paginator's COUNT query cannot see.
        if ($request->filled('min_rating') && ($minRating = (float) $request->query('min_rating')) > 0) {
            $q->whereRaw(
                '(select coalesce(avg(stars), 0) from package_ratings where package_ratings.tour_package_id = tour_packages.id) >= ?',
                [$minRating],
            );
        }

        // Sorting always ends on a unique column. Without that tiebreaker,
        // rows with equal price can swap between pages and a traveller sees
        // the same package twice while never seeing another.
        match ($request->string('sort')->toString()) {
            'price_asc' => $q->orderBy('price')->orderByDesc('id'),
            'price_desc' => $q->orderByDesc('price')->orderByDesc('id'),
            'duration_asc' => $q->orderBy('duration_days')->orderBy('price')->orderByDesc('id'),
            'duration_desc' => $q->orderByDesc('duration_days')->orderBy('price')->orderByDesc('id'),
            'rating' => $q->orderByDesc('ratings_avg_stars')->orderByDesc('ratings_count')->orderByDesc('id'),
            'newest' => $q->orderByDesc('id'),
            // Default: the order the CMS editor arranged.
            default => $q->orderBy('sort_order')->orderByDesc('id'),
        };

        return response()->json([
            'data' => $q->paginate(min(50, max(1, (int) $request->query('per_page', '12'))))
                ->appends($request->query()),
        ]);
    }

    /**
     * GET /catalog/tour-package-facets
     *
     * The option lists behind the filter panel — destinations, facilities and
     * the real price/duration bounds.
     *
     * These are derived from the published rows instead of being hard-coded in
     * the frontend, which is the whole point of a CMS: an editor who adds a
     * package to a new destination gets that destination as a filter option
     * without a deploy, and an editor who retires one stops offering a filter
     * that can only ever return nothing.
     */
    public function catalogPackageFacets(): JsonResponse
    {
        $base = TourPackage::query()->where('status', 'active');

        $destinations = (clone $base)
            ->whereNotNull('destination')
            ->where('destination', '!=', '')
            ->selectRaw('destination, count(*) as total')
            ->groupBy('destination')
            ->orderByDesc('total')
            ->orderBy('destination')
            ->limit(60)
            ->get()
            ->map(fn ($row): array => ['value' => (string) $row->destination, 'count' => (int) $row->total])
            ->values();

        $bounds = (clone $base)
            ->selectRaw('min(price) as min_price, max(price) as max_price, min(duration_days) as min_days, max(duration_days) as max_days')
            ->first();

        // Facilities live inside a JSON column, so the distinct list is folded
        // in PHP. Only the column is selected — this is a few hundred short
        // arrays at catalogue scale, not a table scan of full rows.
        $facilities = [];
        foreach ((clone $base)->whereNotNull('facilities')->pluck('facilities') as $raw) {
            $list = is_array($raw) ? $raw : (json_decode((string) $raw, true) ?: []);
            foreach ((array) $list as $item) {
                if (! is_string($item)) {
                    continue;
                }
                $name = trim($item);
                if ($name === '') {
                    continue;
                }
                $facilities[$name] = ($facilities[$name] ?? 0) + 1;
            }
        }
        arsort($facilities);
        $facilities = array_slice($facilities, 0, 30, true);

        return response()->json(['data' => [
            'destinations' => $destinations,
            // Keys are cast back to string: PHP silently turns a numeric-looking
            // array key into an int, and a facility literally named "2024" would
            // otherwise arrive at the client with a different type than its
            // neighbours.
            'facilities' => array_map(
                static fn ($value, $count): array => ['value' => (string) $value, 'count' => (int) $count],
                array_keys($facilities),
                array_values($facilities),
            ),
            'price' => [
                'min' => (float) ($bounds?->min_price ?? 0),
                'max' => (float) ($bounds?->max_price ?? 0),
            ],
            'duration' => [
                'min' => (int) ($bounds?->min_days ?? 1),
                'max' => (int) ($bounds?->max_days ?? 1),
            ],
            'total' => (clone $base)->count(),
        ]]);
    }

    /**
     * Strip LIKE metacharacters from a user-supplied term.
     *
     * Backslash-escaping them would be the richer answer, but it only works
     * where the driver treats `\` as the default LIKE escape — MySQL does,
     * SQLite does not without an explicit `ESCAPE` clause the query builder
     * will not emit here. Removing the characters behaves identically on every
     * driver this app is installed on. The values are bound parameters either
     * way, so this is about matching correctly, not about injection.
     */
    private function escapeLike(string $value): string
    {
        return str_replace(['\\', '%', '_'], '', $value);
    }

    public function catalogPackageShow(string $slug): JsonResponse
    {
        $package = TourPackage::query()
            ->withCount('ratings')
            ->withAvg('ratings', 'stars')
            ->where('status', 'active')
            ->where('slug', $slug)
            ->firstOrFail();

        return response()->json(['data' => $package]);
    }

    /**
     * Cards for the swipeable recommendation rail on the customer dashboard.
     *
     * Kept separate from catalogHome() rather than filtered client-side: the
     * dashboard would otherwise download every hero, FAQ and footer block just
     * to render two cards, on the connection of someone already logged in on
     * a phone.
     *
     * `link` is emitted only when it is safe to put in an href. A CMS editor
     * is trusted to write copy, not to inject a scheme — `javascript:` or
     * `data:` here would be stored XSS against every logged-in customer, so
     * anything that is not http(s) or a site-relative path is dropped.
     */
    public function catalogRecommendations(): JsonResponse
    {
        $sections = CmsSection::query()
            ->published()
            ->where('section_type', CmsSection::TYPE_RECOMMENDATION)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->limit(20)
            ->get(['id', 'title', 'body', 'image_path', 'link', 'sort_order', 'metadata'])
            ->map(function (CmsSection $section): array {
                return [
                    'id' => $section->id,
                    'title' => $section->title,
                    'body' => $section->body,
                    'image_path' => $section->image_path,
                    'link' => $this->safeLink($section->link),
                    'badge' => is_array($section->metadata) ? ($section->metadata['badge'] ?? null) : null,
                ];
            })
            ->values();

        return response()->json(['data' => $sections]);
    }

    /**
     * GET /catalog/hero-slides
     *
     * The hero carousel as standalone data, for pages that are not driven by
     * the CMS block renderer (the customer package page). The home page gets
     * the same rows through /catalog/home and groups them client-side.
     */
    public function catalogHeroSlides(): JsonResponse
    {
        $slides = CmsSection::query()
            ->published()
            ->where('section_type', CmsSection::TYPE_HERO_SLIDER)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->limit(12)
            ->get(['id', 'title', 'body', 'image_path', 'link', 'metadata'])
            ->map(fn (CmsSection $s): array => [
                'id' => $s->id,
                'title' => $s->title,
                'body' => $s->body,
                'image_path' => $s->image_path,
                'link' => $this->safeLink($s->link),
                'cta_label' => is_array($s->metadata) ? ($s->metadata['cta_label'] ?? null) : null,
            ])
            ->values();

        return response()->json(['data' => $slides]);
    }

    /** Allow site-relative paths and absolute http(s) only; drop everything else. */
    private function safeLink(?string $link): ?string
    {
        $link = trim((string) $link);
        if ($link === '') {
            return null;
        }

        // Site-relative: must start with a single slash, never '//host'
        // (protocol-relative, which escapes to another origin).
        if (str_starts_with($link, '/') && ! str_starts_with($link, '//')) {
            return $link;
        }

        $scheme = parse_url($link, PHP_URL_SCHEME);

        return in_array(strtolower((string) $scheme), ['http', 'https'], true) ? $link : null;
    }

    /** The whole dynamic home page: published sections grouped by type. */
    public function catalogHome(): JsonResponse
    {
        // Flat, ordered list of published blocks — the public renderer lays
        // them out in exactly the order set in the Page Builder.
        $sections = CmsSection::query()->published()
            // Recommendation cards belong to the customer dashboard rail, not
            // the public home page. The renderer already ignores unknown
            // types, but there is no reason to ship them to every visitor.
            ->where('section_type', '!=', CmsSection::TYPE_RECOMMENDATION)
            ->orderBy('sort_order')->orderBy('id')
            ->get(['id', 'section_type', 'title', 'body', 'image_path', 'link', 'sort_order', 'is_active', 'metadata']);
        return response()->json(['data' => $sections]);
    }

    // ------------------- Centralized CMS: versions -------------------

    /** Snapshot the whole CMS state as a draft or published version. */
    public function saveVersion(Request $request): JsonResponse
    {
        $data = $request->validate([
            'label' => 'sometimes|nullable|string|max:120',
            'status' => 'sometimes|in:draft,published',
        ]);
        $status = $data['status'] ?? 'draft';

        $snapshot = [
            'sections' => CmsSection::query()->orderBy('section_type')->orderBy('sort_order')->get()->toArray(),
            'branding' => $this->brandingPayload(),
            'taken_at' => now()->toIso8601String(),
        ];

        $version = CmsVersion::create([
            'label' => $data['label'] ?? ('Snapshot '.now()->format('d M Y H:i')),
            'status' => $status,
            'snapshot' => $snapshot,
            'created_by' => $request->user()?->id,
            'published_at' => $status === 'published' ? now() : null,
        ]);

        if ($status === 'published') {
            // Mark previous published versions superseded (kept for history).
            CmsVersion::where('status', 'published')->whereKeyNot($version->id)->update(['status' => 'draft']);
        }

        $this->audit($request, $status === 'published' ? 'cms.version_published' : 'cms.version_saved', ['id' => $version->id, 'label' => $version->label]);
        return response()->json(['data' => $version], 201);
    }

    public function versions(Request $request): JsonResponse
    {
        return response()->json(['data' => CmsVersion::with('createdBy:id,name')
            ->latest('id')->paginate(min(50, max(1, (int) $request->query('per_page', '20'))))]);
    }

    /** Restore a version: re-materialise its sections into cms_sections. */
    public function restoreVersion(Request $request, string $id): JsonResponse
    {
        $version = CmsVersion::findOrFail($id);
        $sections = $version->snapshot['sections'] ?? [];

        DB::transaction(function () use ($sections): void {
            CmsSection::query()->forceDelete();
            foreach ($sections as $s) {
                CmsSection::create([
                    'uuid' => (string) Str::uuid(),
                    'section_type' => $s['section_type'] ?? 'hero',
                    'title' => $s['title'] ?? null,
                    'body' => $s['body'] ?? null,
                    'image_path' => $s['image_path'] ?? null,
                    'link' => $s['link'] ?? null,
                    'sort_order' => (int) ($s['sort_order'] ?? 0),
                    'is_active' => (bool) ($s['is_active'] ?? true),
                    'publish_start' => $s['publish_start'] ?? null,
                    'publish_end' => $s['publish_end'] ?? null,
                    'metadata' => $s['metadata'] ?? null,
                ]);
            }
        });

        $this->audit($request, 'cms.version_restored', ['id' => $version->id, 'label' => $version->label]);
        return response()->json(['data' => ['restored' => true, 'sections' => count($sections)]]);
    }

    // ------------------- Centralized CMS: branding -------------------

    /** Branding/typography/SEO/company profile — stored in System Settings. */
    public function branding(): JsonResponse
    {
        return response()->json(['data' => $this->brandingPayload()]);
    }

    public function brandingUpdate(Request $request): JsonResponse
    {
        $data = $request->validate([
            'logo_path' => 'sometimes|nullable|string|max:255',
            'primary_color' => 'sometimes|nullable|string|max:16',
            'font_family' => 'sometimes|nullable|string|max:64',
            'company_name' => 'sometimes|nullable|string|max:150',
            'company_tagline' => 'sometimes|nullable|string|max:255',
            'social' => 'sometimes|nullable|array',
            'seo' => 'sometimes|nullable|array',
        ]);
        foreach ($data as $key => $value) {
            \App\Models\SystemSetting::updateOrCreate(['key' => 'cms_'.$key], ['value' => $value, 'is_public' => true]);
        }
        $this->audit($request, 'cms.branding_updated', ['keys' => array_keys($data)]);
        return response()->json(['data' => $this->brandingPayload()]);
    }

    /** @return array<string, mixed> */
    private function brandingPayload(): array
    {
        $keys = ['logo_path', 'primary_color', 'font_family', 'company_name', 'company_tagline', 'social', 'seo'];
        $out = [];
        foreach ($keys as $k) {
            $value = \App\Models\SystemSetting::query()->where('key', 'cms_'.$k)->value('value');
            $out[$k] = is_array($value) ? ($value['value'] ?? $value) : $value;
        }
        return $out;
    }

    /** General image upload (cover/gallery) — reuses the public storage disk. */
    public function upload(Request $request): JsonResponse
    {
        // `max:` is expressed against the server's own ceiling rather than a
        // hard-coded number: a rule of 6144 on a host where PHP stops at 2 MB
        // can never fire, so the operator gets "wajib diisi" for a file they
        // plainly chose. ImageUploadService reports the real reason.
        $limitKb = ImageUploadService::serverLimitMb() * 1024;
        $request->validate(['image' => "required|file|max:{$limitKb}"]);

        $result = app(ImageUploadService::class)->store($request->file('image'), 'cms');
        $this->audit($request, 'cms.image_uploaded', ['path' => $result['path']]);

        return response()->json(['data' => $result], 201);
    }

    private function audit(Request $request, string $action, array $meta): void
    {
        $meta = RequestContext::enrich($request, $meta);
        AuditTrail::record($action, 'Cms', 'user', (string) $request->user()?->id, $meta);
        ActivityLog::create(['action' => $action, 'subject_type' => 'Cms', 'subject_id' => $meta['id'] ?? null, 'metadata' => $meta]);
    }
}
