<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\ActivityLog;
use App\Models\AuditTrail;
use App\Support\Audit\RequestContext;
use App\Support\Messaging\WhatsAppTemplate;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * WhatsApp message-template editor for admin and owner.
 *
 * Mirrors EmailTemplateController: list defaults beside overrides, save one
 * type at a time, preview with sample values. Clearing a template restores the
 * code default rather than sending an empty message — an operator who empties
 * the box means "go back to normal", not "send nothing".
 */
final class WhatsAppTemplateController extends Controller
{
    /** Sample values for the live preview, chosen to look like real records. */
    private const SAMPLE = [
        'customer_name' => 'Andi Santoso',
        'sender_name' => 'Rina Wijaya',
        'receiver_name' => 'Budi Hartono',
        'driver_name' => 'Pak Slamet',
        'company' => 'SJT Travel & Tour',
        'booking_code' => 'BK-1042',
        'package_code' => 'JST-4K7M-92XP',
        'item_name' => 'Dokumen penting',
        'pickup' => 'Terminal Bungurasih, Sidoarjo',
        'drop' => 'Stasiun Malang Kota Baru',
        'seats' => '3A, 3B',
        'vehicle' => 'Toyota HiAce · L 1234 AB',
    ];

    public function index(): JsonResponse
    {
        $overrides = WhatsAppTemplate::all();

        $templates = [];
        foreach (WhatsAppTemplate::DEFAULTS as $type => $def) {
            $templates[] = [
                'type' => $type,
                'label' => $def['label'],
                'description' => $def['description'],
                'placeholders' => $def['placeholders'],
                'default' => $def['body'],
                'override' => $overrides[$type] ?? '',
            ];
        }

        return response()->json(['data' => $templates]);
    }

    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'type' => 'required|in:'.implode(',', array_keys(WhatsAppTemplate::DEFAULTS)),
            'body' => 'sometimes|nullable|string|max:'.WhatsAppTemplate::MAX_LENGTH,
        ]);

        $type = $data['type'];
        $body = trim((string) ($data['body'] ?? ''));

        $all = WhatsAppTemplate::all();
        if ($body === '') {
            unset($all[$type]); // cleared → fall back to the code default
        } else {
            $all[$type] = $body;
        }
        WhatsAppTemplate::put($all);

        $meta = RequestContext::enrich($request, ['type' => $type, 'cleared' => $body === '']);
        AuditTrail::record('cms.whatsapp_template_updated', 'WhatsAppTemplate', 'user', (string) $request->user()?->id, $meta);
        ActivityLog::create(['action' => 'cms.whatsapp_template_updated', 'subject_type' => 'WhatsAppTemplate', 'subject_id' => null, 'metadata' => $meta]);

        return response()->json(['data' => ['type' => $type, 'saved' => true]]);
    }

    /** Live preview with sample values, so wording is checked before it ships. */
    public function preview(Request $request): JsonResponse
    {
        $data = $request->validate([
            'type' => 'required|in:'.implode(',', array_keys(WhatsAppTemplate::DEFAULTS)),
            'body' => 'sometimes|nullable|string|max:'.WhatsAppTemplate::MAX_LENGTH,
        ]);

        $raw = trim((string) ($data['body'] ?? '')) ?: WhatsAppTemplate::DEFAULTS[$data['type']]['body'];
        $rendered = WhatsAppTemplate::render($raw, self::SAMPLE + ['company' => WhatsAppTemplate::companyName()]);

        return response()->json(['data' => ['body' => $rendered, 'length' => mb_strlen($rendered)]]);
    }
}
