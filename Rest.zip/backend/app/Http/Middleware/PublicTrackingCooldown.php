<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Models\ActivityLog;
use App\Models\SystemSetting;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

/**
 * Cooldown for the public package-tracking lookup.
 *
 * Separate from CustomerActionCooldown, which guards *creating* things and is
 * keyed by user id. This endpoint has no user: anyone holding a receipt code
 * can use it, so the key is the caller's address and the thing being defended
 * is the code space itself.
 *
 * The rule that makes this work is that **only a failed lookup starts the
 * cooldown**. That is the opposite of arming it on every request, and it is
 * deliberate:
 *
 *   · An attacker enumerating codes produces failures almost exclusively. They
 *     are held to one guess per cooldown window — against a keyspace of ~10^12
 *     that is not an attack, it is a hobby.
 *
 *   · A customer who types their own code correctly is never delayed, and can
 *     come back to check on the package as often as they like. Arming on every
 *     request would have made the tracking page unusable for exactly the people
 *     it exists for, without slowing an attacker down any further.
 *
 * A customer who mistypes does wait out the window. That is the real cost, and
 * it is why the codes avoid characters that are easy to misread.
 *
 * Window length comes from System Settings (`package_tracking_cooldown_minutes`,
 * default 2). Setting it to 0 disables the cooldown; the route's own throttle
 * still applies.
 */
final class PublicTrackingCooldown
{
    /** Marker the controller sets on a response it considers a miss. */
    public const FAILED_HEADER = 'X-Tracking-Lookup-Failed';

    public function handle(Request $request, Closure $next): Response
    {
        $minutes = (int) ($this->setting('package_tracking_cooldown_minutes') ?? 2);
        if ($minutes <= 0) {
            return $next($request);
        }

        $key = 'tracking:cooldown:'.sha1((string) $request->ip());

        $until = Cache::get($key);
        if ($until !== null) {
            $seconds = max(1, (int) round(now()->diffInSeconds($this->asDate($until), false)));

            ActivityLog::create([
                'action' => 'tracking.cooldown_hit',
                'subject_type' => 'JastipOrder',
                'subject_id' => null,
                'metadata' => ['ip' => $request->ip(), 'retry_after_seconds' => $seconds],
            ]);

            return response()->json([
                'success' => false,
                'message' => "Terlalu banyak percobaan. Coba lagi dalam {$seconds} detik.",
                'data' => ['retry_after_seconds' => $seconds],
            ], 429)->header('Retry-After', (string) $seconds);
        }

        $response = $next($request);

        // Arm the window only when the controller reports a miss. Anything
        // else — a hit, a validation error, a server fault — leaves the caller
        // free to try again.
        if ($response->headers->has(self::FAILED_HEADER)) {
            $response->headers->remove(self::FAILED_HEADER);
            Cache::put($key, now()->addMinutes($minutes), now()->addMinutes($minutes));
        }

        return $response;
    }

    /** Cache drivers may hand back a Carbon instance or its serialised form. */
    private function asDate(mixed $value): \Illuminate\Support\Carbon
    {
        return $value instanceof \Illuminate\Support\Carbon
            ? $value
            : \Illuminate\Support\Carbon::parse((string) $value);
    }

    private function setting(string $key): mixed
    {
        $value = SystemSetting::query()->where('key', $key)->value('value');

        return is_array($value) ? ($value['value'] ?? null) : $value;
    }
}
