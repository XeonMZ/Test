<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

final class RegisterRequest extends FormRequest
{
    public function authorize(): bool { return true; }

    /**
     * Usernames are matched case-insensitively, so they are stored lowercase.
     * Without this "Andi" and "andi" would both pass the unique check and then
     * collide the moment either tries to log in by name.
     */
    protected function prepareForValidation(): void
    {
        if ($this->has('username')) {
            $this->merge(['username' => mb_strtolower(trim((string) $this->input('username')))]);
        }
    }

    public function rules(): array { return ['name' => ['required', 'string', 'max:255'], 'username' => ['required', 'string', 'alpha_dash', 'min:3', 'max:64', 'unique:users,username'], 'email' => ['required', 'email', 'unique:users,email'], 'password' => ['required', 'confirmed', Password::defaults()], 'phone' => ['required', 'string', 'max:30']]; }

    /**
     * Messages in the user's language, because the defaults for `alpha_dash`
     * ("may only contain letters, numbers, dashes and underscores") arrive in
     * English and read as a system error to someone registering in Indonesian.
     *
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'username.required' => 'Username wajib diisi.',
            'username.alpha_dash' => 'Username hanya boleh berisi huruf, angka, tanda hubung (-), dan garis bawah (_).',
            'username.min' => 'Username minimal 3 karakter.',
            'username.max' => 'Username maksimal 64 karakter.',
            'username.unique' => 'Username ini sudah dipakai. Silakan pilih yang lain.',
        ];
    }
}
