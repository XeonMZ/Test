<?php

declare(strict_types=1);

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

/** Refund processed notice. */
final class PaymentRefundedMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public readonly string $name,
        public readonly string $bookingCode,
        /** The base fare returned to the customer, pre-formatted. */
        public readonly string $amount,
        /** Admin fee + tax kept back, pre-formatted, or null when there was none. */
        public readonly ?string $withheld = null,
    ) {}

    public function build(): self
    {
        return $this
            ->subject('Refund Processed - SJT Travel')
            ->view('emails.payment-refunded')
            ->text('emails.payment-refunded-text')
            ->with([
                'name' => $this->name,
                'bookingCode' => $this->bookingCode,
                'amount' => $this->amount,
                'withheld' => $this->withheld,
            ]);
    }
}
