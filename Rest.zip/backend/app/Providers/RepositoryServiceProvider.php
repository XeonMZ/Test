<?php

declare(strict_types=1);

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

final class RepositoryServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $bindings = [
            \App\Modules\Booking\Domain\Repositories\BookingRepository::class => \App\Modules\Booking\Infrastructure\Repositories\EloquentBookingRepository::class,
            \App\Support\Cache\CacheStore::class => \App\Support\Cache\LaravelCacheStore::class,
            \App\Support\Settings\SettingsRepository::class => \App\Support\Settings\DatabaseSettingsRepository::class,
            \App\Support\FeatureFlags\FeatureFlagRepository::class => \App\Support\FeatureFlags\DatabaseFeatureFlagRepository::class,
            \App\Modules\Gps\Domain\Repositories\DriverLocationRepository::class => \App\Modules\Gps\Infrastructure\EloquentDriverLocationRepository::class,
            \App\Modules\Payments\Domain\Repositories\PaymentRepository::class => \App\Modules\Payments\Infrastructure\Repositories\EloquentPaymentRepository::class,
            \App\Modules\Tickets\Domain\Repositories\TicketRepository::class => \App\Modules\Tickets\Infrastructure\Repositories\EloquentTicketRepository::class,
            \App\Modules\Tickets\Infrastructure\Storage\TicketStorage::class => \App\Modules\Tickets\Infrastructure\Storage\LocalTicketStorage::class,
        ];
        $this->app->bind(\App\Modules\Payments\Domain\Repositories\PaymentGateway::class, function (): \App\Modules\Payments\Domain\Repositories\PaymentGateway {
            // Beta payment mode is an explicit, owner-controlled feature flag.
            // When ON it forces the offline simulation gateway even if a real
            // provider is configured, so an owner can rehearse the full payment
            // flow on a live install without moving real money. When OFF — the
            // default — this whole block is skipped and gateway selection is
            // exactly what it always was.
            //
            // The flag is read through a guarded helper: this binding resolves
            // during boot, including mid-install before the feature_flags table
            // exists, so a DB error here must degrade to "beta off" rather than
            // blow up the container.
            if ($this->paymentBetaEnabled()) {
                return new \App\Modules\Payments\Infrastructure\Gateways\BetaPaymentGateway();
            }

            $configured = (string) config('payment.gateway', 'auto');
            $hasMidtransKey = (string) config('payment.midtrans.server_key') !== '';
            $useMidtrans = $configured === 'midtrans' || ($configured === 'auto' && $hasMidtransKey);

            if ($useMidtrans) {
                return \App\Modules\Payments\Infrastructure\Gateways\MidtransGateway::fromEnvironment();
            }

            if (app()->environment('production')) {
                \Illuminate\Support\Facades\Log::warning('Payment gateway is running in beta (offline) mode in production; webhooks will be rejected. Configure PAYMENT_GATEWAY=midtrans and MIDTRANS_SERVER_KEY, or enable the payment_beta feature flag to allow simulated payments.');
            }

            return new \App\Modules\Payments\Infrastructure\Gateways\BetaPaymentGateway();
        });

        foreach ($bindings as $abstract => $concrete) {
            $this->app->bind($abstract, $concrete);
        }
    }

    /**
     * Whether beta payment mode is switched on, read safely.
     *
     * Resolves the flag through the same cached service the rest of the app
     * uses, but wrapped so that a missing table or unavailable database — both
     * possible while this provider boots during installation — is treated as
     * "off". Payment behaviour must never depend on a query that might not be
     * answerable yet.
     */
    private function paymentBetaEnabled(): bool
    {
        try {
            return app(\App\Support\FeatureFlags\FeatureFlagService::class)
                ->enabled(\App\Support\FeatureFlags\FeatureFlagDefinition::PaymentBeta);
        } catch (\Throwable) {
            return false;
        }
    }
}
