<?php

declare(strict_types=1);

namespace App\Modules\Auth\Application\Services;

use App\Events\PasswordChanged;
use App\Mail\OtpMail;
use App\Models\ActivityLog;
use App\Models\User;
use App\Support\Auth\OtpService;
use App\Support\Mail\TransactionalMailer;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Password reset by one-time passcode.
 *
 * The previous implementation answered "Email tidak terdaftar." on unknown
 * addresses, which turns this endpoint into a free account-enumeration oracle:
 * anyone could confirm whether a given person has an account here just by
 * watching the response. Every path now returns one identical message, and the
 * only observable difference is whether an email lands in a mailbox the caller
 * already controls.
 *
 * Keeping that property is subtle — see the cooldown handling in forgot().
 */
final class PasswordService
{
    public function __construct(
        private readonly OtpService $otp,
        private readonly TransactionalMailer $mailer,
    ) {}

    /** Uniform reply for every branch, so nothing distinguishes the cases. */
    private const GENERIC_REPLY = 'Jika email tersebut terdaftar, kami telah mengirimkan kode verifikasi. Periksa kotak masuk dan folder spam Anda.';

    private const GENERIC_OTP_ERROR = 'Kode verifikasi salah atau sudah kedaluwarsa. Minta kode baru bila perlu.';

    public function forgot(array $data, ?string $ip = null, ?string $userAgent = null): string
    {
        $email = mb_strtolower(trim((string) $data['email']));
        $user = User::where('email', $email)->first();

        if ($user === null) {
            ActivityLog::create([
                'action' => 'auth.password_reset_unknown_email',
                'subject_type' => 'User',
                'subject_id' => null,
                'metadata' => ['email' => $email, 'ip' => $ip],
            ]);

            return self::GENERIC_REPLY;
        }

        // Reset-by-email requires a verified email. The reasoning is a chain:
        // resetting the password is the one action that lets someone take over
        // an account using only inbox access, and if the address was never
        // proven to belong to this user, we would be handing the account to
        // whoever happens to hold that inbox — including the real owner of a
        // mistyped address who never asked for any of this. Verification is the
        // step that proves the inbox and the account are the same person.
        //
        // Answered with the SAME generic reply as every other branch: telling
        // the caller "this account is not verified" would confirm the address
        // is registered, which is exactly the enumeration leak this method is
        // built to avoid. The unverified user instead receives a verification
        // code (not a reset code), which is the action actually open to them.
        if ($user->email_verified_at === null) {
            ActivityLog::create([
                'action' => 'auth.password_reset_blocked_unverified',
                'subject_type' => 'User',
                'subject_id' => $user->getKey(),
                'metadata' => ['email' => $email, 'ip' => $ip],
            ]);

            // Nudge them down the path that IS available: prove the inbox
            // first. Best-effort — the resend cooldown is swallowed exactly as
            // it is for a reset, so timing never distinguishes the branches.
            try {
                $issued = $this->otp->issue($email, OtpService::PURPOSE_EMAIL_VERIFICATION, $user, $ip, $userAgent);
                $this->mailer->queue(
                    'verify_email',
                    $email,
                    'Verifikasi Email Anda - SJT Travel',
                    new OtpMail(
                        recipientName: (string) $user->name,
                        toAddress: $email,
                        code: $issued['code'],
                        purpose: OtpService::PURPOSE_EMAIL_VERIFICATION,
                        expireMinutes: $this->otp->ttlMinutes(),
                        requestIp: $ip,
                        requestedAt: now()->translatedFormat('d F Y, H:i').' WIB',
                    ),
                    "user:{$user->getKey()}:verify:".now()->format('YmdHis'),
                    (int) $user->getKey(),
                );
            } catch (ValidationException) {
                // Cooldown — no second email, same silent outcome as a stranger.
            }

            return self::GENERIC_REPLY;
        }

        try {
            $issued = $this->otp->issue($email, OtpService::PURPOSE_PASSWORD_RESET, $user, $ip, $userAgent);
        } catch (ValidationException) {
            // The resend cooldown fired. Surfacing that would reveal the
            // address exists — only a known account can be in cooldown.
            // Swallow it and answer exactly as we would for a stranger; the
            // caller simply gets no second email.
            return self::GENERIC_REPLY;
        }

        $this->mailer->queue(
            'reset_password',
            $email,
            'Kode Reset Password Anda - SJT Travel',
            new OtpMail(
                recipientName: (string) $user->name,
                toAddress: $email,
                code: $issued['code'],
                purpose: OtpService::PURPOSE_PASSWORD_RESET,
                expireMinutes: $this->otp->ttlMinutes(),
                requestIp: $ip,
                requestedAt: now()->translatedFormat('d F Y, H:i').' WIB',
            ),
            // Rotates per issued code, so a genuine re-request is never
            // swallowed by the mailer's duplicate suppression.
            "user:{$user->getKey()}:reset:".now()->format('YmdHis'),
            (int) $user->getKey(),
        );

        return self::GENERIC_REPLY;
    }

    public function reset(array $data, ?string $ip = null): string
    {
        $email = mb_strtolower(trim((string) $data['email']));

        // Throws the deliberately vague OTP error on any failure mode.
        $this->otp->verify($email, OtpService::PURPOSE_PASSWORD_RESET, (string) $data['code'], $ip);

        $user = User::where('email', $email)->first();
        if ($user === null) {
            // Only reachable if the account vanished between issue and
            // redeem; treat it as a failed code rather than explaining.
            throw ValidationException::withMessages(['code' => [self::GENERIC_OTP_ERROR]]);
        }

        // Enforce the verification gate on redemption too, not only on request.
        // forgot() will not issue a reset code to an unverified account — but a
        // code issued while the account was verified must not stay usable if
        // verification was later revoked, and no reset should ever complete
        // against an unproven inbox regardless of how the code was obtained.
        // Reported as a generic code failure so it leaks nothing.
        if ($user->email_verified_at === null) {
            throw ValidationException::withMessages(['code' => [self::GENERIC_OTP_ERROR]]);
        }

        $user->forceFill([
            'password' => Hash::make((string) $data['password']),
            'remember_token' => Str::random(60),
        ])->save();

        // Anyone holding a session on this account loses it — that is the
        // point of a reset when the account may already be compromised.
        $user->tokens()->delete();

        // Nothing outstanding should survive a completed reset, including any
        // pending verification code for the same mailbox.
        $this->otp->revokeAll($email);

        event(new PasswordReset($user));
        PasswordChanged::dispatch($user, ['reset' => true]);

        ActivityLog::create([
            'action' => 'auth.password_reset',
            'subject_type' => 'User',
            'subject_id' => $user->getKey(),
            'metadata' => ['email' => $email, 'ip' => $ip],
        ]);

        return 'Password berhasil diubah. Silakan masuk dengan password baru Anda.';
    }

    public function change(User $user, string $password): void
    {
        $user->forceFill(['password' => Hash::make($password)])->save();
        $user->tokens()->where('id', '!=', $user->currentAccessToken()?->id)->delete();
        PasswordChanged::dispatch($user, ['reset' => false]);
    }
}
