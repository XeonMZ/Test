<?php

declare(strict_types=1);

namespace App\Modules\Payments\Presentation;

use App\Models\Booking;
use App\Models\User;
use App\Modules\Payments\Application\Services\PaymentService;
use App\Modules\Payments\Application\Services\PaymentWebhookService;
use App\Modules\Payments\Domain\Repositories\PaymentRepository;
use App\Support\Http\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Throwable;

final class PaymentController
{
    private const STAFF_ROLES = ['admin', 'owner'];

    public function store(Request $request, PaymentService $payments): JsonResponse
    {
        $data = $request->validate([
            'booking_uuid' => ['required', 'string'],
            'amount' => ['required', 'integer', 'min:1'],
            'method' => ['required', 'string', 'in:qris,virtual_account,va,bank_transfer,ewallet,snap'],
            'idempotency_key' => ['nullable', 'string', 'max:120'],
            'payment_type' => ['nullable', 'string', 'in:full,dp,settlement'],
        ]);

        $this->authorizeBooking($request->user(), $data['booking_uuid']);

        $result = $payments->createPayment(
            $data['booking_uuid'],
            (int) $data['amount'],
            $data['method'],
            $data['idempotency_key'] ?? $request->header('Idempotency-Key', sha1(json_encode($data))),
            $data['payment_type'] ?? 'full',
        );

        return response()->json(ApiResponse::success('Payment created', $result, 201), 201);
    }

    /**
     * Complete a simulated payment successfully — beta mode only.
     *
     * This is the "berhasil buat bayar" of beta mode: it marks the caller's own
     * pending payment as paid so the whole downstream flow (ticket issuance,
     * confirmation email, booking state) runs, without any real money and
     * without constructing a signed webhook by hand.
     *
     * Four independent gates, all of which must hold — the ordering matters,
     * cheapest and most decisive first:
     *
     *   1. The `payment_beta` feature flag is ON. Off (the default) → 404, as
     *      though this endpoint does not exist.
     *   2. The active gateway is actually the beta one. If a real provider is
     *      bound, simulation is refused — this can never short-circuit a real
     *      Midtrans charge.
     *   3. The caller owns the booking (same check as every other payment
     *      action here). Staff may act on any booking, as elsewhere.
     *   4. The payment is in a state a real webhook could still advance
     *      (pending). Already-paid or failed payments are left untouched.
     */
    public function simulate(Request $request, string $payment, PaymentRepository $payments, PaymentWebhookService $handler): JsonResponse
    {
        // Gate 1: flag. A 404 (not 403) so the endpoint is invisible when off.
        abort_unless($this->betaPaymentEnabled(), 404);

        // Gate 2: the beta gateway must be the one in force.
        $gateway = app(\App\Modules\Payments\Domain\Repositories\PaymentGateway::class);
        abort_unless($gateway instanceof \App\Modules\Payments\Infrastructure\Gateways\BetaPaymentGateway, 422, 'Simulasi hanya tersedia dalam mode pembayaran beta.');

        // The app has two payment worlds and beta must cover both, or it works
        // for tickets and silently 404s for tour packages.
        //
        //   · Travel bookings live in the `payments` table.
        //   · Package bookings carry their gateway order id on their own row.
        //
        // Try travel first, then packages; the UUID belongs to exactly one.
        $entity = $payments->findByUuid($payment);
        if ($entity !== null) {
            // Gate 3: ownership.
            $this->authorizeBooking($request->user(), $entity->bookingUuid);

            // Gate 4: only a still-open payment can be completed. Settling a
            // paid or failed one would be a no-op at best and a double-fire at
            // worst; the state machine inside forceStatus() would reject the
            // transition anyway, but refusing here gives a clear message.
            abort_unless($entity->status === \App\Modules\Payments\Domain\ValueObjects\PaymentStatus::Pending, 422, 'Pembayaran ini sudah tidak dalam status menunggu pembayaran.');

            // Drive it to paid through the SAME path a verified gateway webhook
            // uses, so ticketing, invoice email and booking state behave
            // identically to a real success — the whole point of a rehearsal.
            $updated = $handler->forceStatus(
                $entity,
                \App\Modules\Payments\Domain\ValueObjects\PaymentStatus::Paid,
                ['beta_simulated' => true, 'simulated_by' => $request->user()?->id, 'simulated_at' => now()->toISOString()],
            );

            \App\Models\ActivityLog::create([
                'action' => 'payment.beta_simulated',
                'subject_type' => 'Payment',
                'subject_id' => null,
                'metadata' => ['payment_uuid' => $entity->uuid, 'booking_uuid' => $entity->bookingUuid, 'by' => $request->user()?->id],
            ]);

            return response()->json(ApiResponse::success('Simulated payment completed', ['payment' => $updated]));
        }

        // Package booking — matched on either the first-payment order id or the
        // settlement order id, so simulating a DP's remainder works too.
        $package = \App\Models\PackageBooking::where('payment_uuid', $payment)
            ->orWhere('settlement_uuid', $payment)
            ->first();
        abort_if($package === null, 404, 'Pembayaran tidak ditemukan.');

        // Gate 3 (package): ownership. Staff may act on any booking, matching
        // authorizeBooking; a customer may only complete their own.
        $user = $request->user();
        if ($user === null || ! in_array($user->role, self::STAFF_ROLES, true)) {
            $customerId = $user?->customer?->id;
            abort_if($customerId === null, 403, 'Profil customer tidak ditemukan.');
            abort_unless((int) $package->customer_id === (int) $customerId, 403, 'Booking ini bukan milik Anda.');
        }

        // Settle through the SAME path a real paid webhook uses, which also
        // fires the package confirmation email and notification. Idempotent:
        // an already-settled booking returns false rather than paying twice.
        $settled = app(\App\Http\Controllers\Support\PackagePaymentService::class)->simulatePaid($payment);
        abort_unless($settled, 422, 'Pembayaran paket ini sudah tidak dalam status menunggu pembayaran.');

        \App\Models\ActivityLog::create([
            'action' => 'payment.beta_simulated',
            'subject_type' => 'PackageBooking',
            'subject_id' => $package->id,
            'metadata' => ['order_id' => $payment, 'booking_code' => $package->code, 'by' => $request->user()?->id],
        ]);

        return response()->json(ApiResponse::success('Simulated package payment completed', ['package' => true]));
    }

    /** Beta payment flag, read safely (defaults to off). */
    private function betaPaymentEnabled(): bool
    {
        try {
            return app(\App\Support\FeatureFlags\FeatureFlagService::class)
                ->enabled(\App\Support\FeatureFlags\FeatureFlagDefinition::PaymentBeta);
        } catch (\Throwable) {
            return false;
        }
    }

    public function webhook(Request $request, PaymentWebhookService $handler): JsonResponse
    {
        $payload = $request->all();
        $orderId = (string) ($payload['order_id'] ?? '');

        // Package bookings carry their gateway order_id on their own row (the
        // shared payments table is FK-bound to travel bookings). If this order
        // belongs to a package, verify the signature with the SAME gateway and
        // settle it here; otherwise fall through to the travel webhook.
        if ($orderId !== '' && \App\Models\PackageBooking::where('payment_uuid', $orderId)->exists()) {
            $gateway = app(\App\Modules\Payments\Domain\Repositories\PaymentGateway::class);
            if (! $gateway->verifyWebhook($payload)) {
                return response()->json(['success' => false, 'message' => 'Invalid payment webhook signature.', 'data' => []], 422);
            }
            $service = app(\App\Http\Controllers\Support\PackagePaymentService::class);
            $settled = $service->settleFromWebhook($orderId, $payload);
            if ($settled) {
                // Same notification + invoice email the beta simulation sends,
                // from one shared method so the two cannot diverge.
                $service->notifyPaid($orderId);
            }
            return response()->json(ApiResponse::success('Webhook processed', ['package' => $settled]));
        }

        try {
            $payment = $handler->handle($payload);
        } catch (Throwable $exception) {
            return response()->json(['success' => false, 'message' => $exception->getMessage(), 'data' => []], 422);
        }

        return response()->json(ApiResponse::success('Webhook processed', ['payment' => $payment]));
    }

    /** Customers may only touch payments belonging to their own bookings. */
    private function authorizeBooking(?User $user, string $bookingUuid): void
    {
        if ($user !== null && in_array($user->role, self::STAFF_ROLES, true)) {
            return;
        }

        $customerId = $user?->customer?->id;
        abort_if($customerId === null, 403, 'Profil customer tidak ditemukan.');

        $owns = Booking::where('uuid', $bookingUuid)->where('customer_id', $customerId)->exists();
        abort_unless($owns, 403, 'Booking ini bukan milik Anda.');
    }
}
