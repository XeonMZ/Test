<?php

namespace App\Modules\Payments\Infrastructure\Gateways;

use App\Modules\Payments\Domain\Entities\PaymentRecord;
use App\Modules\Payments\Domain\Repositories\PaymentGateway;

/**
 * Sandbox/demo gateway used when no real payment provider is configured, or
 * when the `payment_beta` feature flag is switched on to rehearse payments.
 *
 * Security: webhook verification here uses a shared secret so that even the
 * demo gateway cannot be spoofed by anonymous callers. In production this
 * gateway refuses webhooks entirely UNLESS the owner has explicitly enabled
 * beta payment mode — without that flag, a real provider (e.g. Midtrans) must
 * be configured, otherwise anyone could forge a "paid" callback and mint
 * tickets. Even with the flag on, a valid shared-secret signature is still
 * required, so enabling beta mode opens simulated payments to the owner, never
 * an anonymous forger.
 */
final class BetaPaymentGateway implements PaymentGateway
{
    public function createCharge(PaymentRecord $payment): array
    {
        return match ($payment->method) {
            'snap' => ['redirect_url' => url('/payment/beta/'.$payment->uuid), 'reference' => $payment->uuid],
            'qris' => ['qr_string' => 'sjt-beta-qris://'.$payment->uuid, 'reference' => $payment->uuid],
            'bank_transfer', 'va' => ['va_number' => '0000'.substr(preg_replace('/\D/', '', $payment->uuid), 0, 8), 'reference' => $payment->uuid],
            default => ['reference' => $payment->uuid],
        };
    }

    /** @param array<string, mixed> $payload */
    public function verifyWebhook(array $payload): bool
    {
        // In production, unverified/simulated webhooks are refused unless the
        // owner has switched on beta payment mode. Off (the default) keeps the
        // original guarantee: no beta callback settles a payment in production.
        if (app()->environment('production') && ! $this->betaModeEnabled()) {
            return false;
        }

        // Everywhere the gateway is allowed to run, a shared-secret signature
        // is still mandatory, so the endpoint cannot be triggered by an
        // anonymous attacker who guesses an order_id.
        $secret = (string) config('payment.beta.webhook_secret', '');
        if ($secret === '') {
            return false;
        }

        $provided = (string) ($payload['beta_signature'] ?? '');
        $expected = hash_hmac('sha256', (string) ($payload['order_id'] ?? '').(string) ($payload['transaction_status'] ?? ''), $secret);

        return hash_equals($expected, $provided);
    }

    /** Beta payment mode flag, read safely (defaults to off on any error). */
    private function betaModeEnabled(): bool
    {
        try {
            return app(\App\Support\FeatureFlags\FeatureFlagService::class)
                ->enabled(\App\Support\FeatureFlags\FeatureFlagDefinition::PaymentBeta);
        } catch (\Throwable) {
            return false;
        }
    }
}
