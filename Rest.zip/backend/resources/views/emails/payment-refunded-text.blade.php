REFUND DIPROSES — SJT Travel

Halo {{ $name }}, refund {{ $amount }} untuk booking {{ $bookingCode }} telah diproses. Dana kembali dalam 3-14 hari kerja sesuai penyedia pembayaran.
@isset($withheld)

Sesuai Kebijakan Pengembalian Dana, refund mencakup biaya pokok saja. Biaya administrasi dan pajak {{ $withheld }} bersifat tidak dapat dikembalikan.
@endisset

Bantuan: mail@sekawanjayatrans.com

SJT Travel — sekawanjayatrans.com
