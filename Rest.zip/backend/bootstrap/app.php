<?php

declare(strict_types=1);

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(api: __DIR__.'/../routes/api.php', channels: __DIR__.'/../routes/channels.php', commands: __DIR__.'/../routes/console.php', health: '/up')
    ->withMiddleware(function (Middleware $middleware): void {
        // Pure bearer-token API (tokens issued at login, sent via the
        // Authorization header). statefulApi() is intentionally NOT enabled:
        // it would switch requests from domains listed in
        // SANCTUM_STATEFUL_DOMAINS to cookie+session auth and demand a CSRF
        // token, producing "CSRF token mismatch" (419) for the SPA.
        $middleware->api(append: [App\Http\Middleware\SecurityHeaders::class]);
        $middleware->alias([
            'role' => App\Http\Middleware\EnsureUserHasRole::class,
            'permission' => App\Http\Middleware\EnsureUserHasPermission::class,
            'active' => App\Http\Middleware\EnsureUserIsActive::class,
            'maintenance' => App\Http\Middleware\RejectWhenMaintenanceMode::class,
            'verified' => Illuminate\Auth\Middleware\EnsureEmailIsVerified::class,
            'verified.email' => App\Http\Middleware\EnsureEmailIsVerified::class,
            'cooldown.customer' => App\Http\Middleware\CustomerActionCooldown::class,
            'cooldown.tracking' => App\Http\Middleware\PublicTrackingCooldown::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        // API-only application: always negotiate JSON so HTML error pages never leak.
        $exceptions->shouldRenderJsonWhen(fn (): bool => true);

        // Domain/state-machine violations (invalid payment method, illegal shift
        // transition, forged webhook signature, …) are client errors, not server
        // faults. Surface their message as a 422 envelope the frontend understands.
        $exceptions->render(function (\InvalidArgumentException|\DomainException $e, \Illuminate\Http\Request $request) {
            return response()->json(['success' => false, 'message' => $e->getMessage(), 'data' => []], 422);
        });
    })
    ->withProviders()
    ->create();
