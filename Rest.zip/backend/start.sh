#!/usr/bin/env bash

set -euo pipefail

mkdir -p \
  storage/app/public \
  storage/app/private \
  storage/framework/cache/data \
  storage/framework/sessions \
  storage/framework/testing \
  storage/framework/views \
  storage/logs \
  bootstrap/cache

echo "==> SJT starting..."

# ==========================================================
# WORKER
# ==========================================================
if [ "${SERVICE_TYPE:-web}" = "worker" ]; then
    echo "==> Worker mode detected."

    php artisan optimize:clear || true

    # Worker tuning — defaults preserve prior behaviour, all overridable via env.
    # INVARIANT: QUEUE_TIMEOUT must stay BELOW config/queue.php retry_after
    # (default 180), otherwise a still-running job is re-reserved mid-flight and
    # runs twice. --queue mirrors REDIS_QUEUE so the worker always listens on the
    # exact queue TransactionalMailer dispatches to. Per-job retry counts (e.g.
    # SendTransactionalEmail) travel in the job payload and are unaffected here,
    # so no global --tries is imposed on unrelated jobs.
    exec php artisan queue:work redis \
        --queue="${REDIS_QUEUE:-default}" \
        --sleep="${QUEUE_SLEEP:-1}" \
        --timeout="${QUEUE_TIMEOUT:-120}" \
        --backoff="${QUEUE_BACKOFF:-60}" \
        --max-time="${QUEUE_MAX_TIME:-3600}" \
        --memory="${QUEUE_MEMORY:-256}" \
        --verbose
fi

echo "==> Web mode detected."

# ==========================================================
# APP KEY
# ==========================================================
if [ -z "${APP_KEY:-}" ]; then
    echo "==> Generating APP_KEY..."
    php artisan key:generate --force
fi

# ==========================================================
# DATABASE
# ==========================================================
echo "==> Running migrations..."
php artisan migrate --force

if [ "${SEED_ON_DEPLOY:-true}" = "true" ]; then
    echo "==> Running seed..."
    php artisan db:seed --force
fi

# ==========================================================
# CACHE
# ==========================================================
php artisan optimize:clear || true
php artisan config:cache
php artisan route:cache || true

php artisan storage:link || true

# ==========================================================
# WEB
# ==========================================================
echo "==> Starting web..."

exec php artisan serve \
    --host=0.0.0.0 \
    --port="${PORT:-8000}"