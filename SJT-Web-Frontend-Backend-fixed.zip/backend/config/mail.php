<?php

// Honor an explicitly configured MAIL_MAILER; default to the safe 'log'
// transport when none is set.
return ['default'=>env('MAIL_MAILER','log'),'mailers'=>['smtp'=>['transport'=>'smtp','host'=>env('MAIL_HOST','127.0.0.1'),'port'=>env('MAIL_PORT',2525),'encryption'=>env('MAIL_ENCRYPTION'),'username'=>env('MAIL_USERNAME'),'password'=>env('MAIL_PASSWORD')],'log'=>['transport'=>'log','channel'=>env('MAIL_LOG_CHANNEL')]],'from'=>['address'=>env('MAIL_FROM_ADDRESS','noreply@stms.test'),'name'=>env('MAIL_FROM_NAME','STMS')]];
