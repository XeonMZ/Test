import { DriverDashboardPage } from '@/features/driver-portal/driver-pages';

export const metadata = { title: 'Dashboard Driver — STMS' };

export default function Page() {
  return <DriverDashboardPage />;
}
