import { CheckInConsole, TripPassengersPanel } from '@/features/driver-portal/driver-pages';
import { PageHeader } from '@/shared/ui/components';

export const metadata = { title: 'Check-in — STMS' };

export default function Page() {
  return (
    <div className="space-y-6">
      <PageHeader title="Check-in Penumpang" description="Verifikasi QR tiket, check-in, boarding, dan penandaan tidak hadir — langsung ke server." />
      <CheckInConsole />
      <TripPassengersPanel />
    </div>
  );
}
