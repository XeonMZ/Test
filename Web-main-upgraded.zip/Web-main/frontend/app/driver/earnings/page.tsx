import { DriverEarningsPage } from '@/features/driver-portal/driver-pages';

export const metadata = { title: 'Pendapatan — STMS' };

export default function Page() {
  return <DriverEarningsPage />;
}
