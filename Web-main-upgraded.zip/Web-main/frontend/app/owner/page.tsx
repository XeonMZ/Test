import { OwnerAnalyticsPage } from '@/features/admin-owner/owner-analytics';

export const metadata = { title: 'Owner Dashboard — STMS' };

export default function Page() {
  return <OwnerAnalyticsPage />;
}
