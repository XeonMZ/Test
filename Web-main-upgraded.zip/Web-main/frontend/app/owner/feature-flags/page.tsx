import { FeatureFlagsPage } from '@/features/admin-owner/owner-ops';

export const metadata = { title: 'Owner — Feature Flags — STMS' };

export default function Page() {
  return <FeatureFlagsPage />;
}
