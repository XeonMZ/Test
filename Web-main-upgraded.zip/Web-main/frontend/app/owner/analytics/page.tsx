import { OwnerAnalyticsPage } from '@/features/admin-owner/owner-analytics';

export const metadata = { title: 'Owner Analytics — STMS' };

export default function Page() {
  return <OwnerAnalyticsPage />;
}
