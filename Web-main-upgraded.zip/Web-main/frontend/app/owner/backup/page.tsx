import { BackupPage } from '@/features/admin-owner/owner-ops';

export const metadata = { title: 'Owner — Backup — STMS' };

export default function Page() {
  return <BackupPage />;
}
