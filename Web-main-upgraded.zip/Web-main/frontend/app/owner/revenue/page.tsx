import { OwnerRevenuePage } from '@/features/admin-owner/owner-analytics';

export const metadata = { title: 'Owner Revenue — STMS' };

export default function Page() {
  return <OwnerRevenuePage />;
}
