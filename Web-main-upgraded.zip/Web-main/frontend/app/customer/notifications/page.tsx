import { NotificationsPage } from '@/features/notification-center/notifications-page';

export const metadata = { title: 'Notifikasi — STMS' };

export default function Page() {
  return <NotificationsPage />;
}
