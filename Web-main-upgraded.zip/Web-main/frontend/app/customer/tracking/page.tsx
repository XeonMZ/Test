import { TrackingPage } from '@/features/customer-portal/portal-pages';

export const metadata = { title: 'Lacak Perjalanan — STMS' };

export default function Page() {
  return <TrackingPage />;
}
