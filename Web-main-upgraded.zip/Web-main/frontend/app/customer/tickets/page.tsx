import { TicketList } from '@/features/customer-portal/ticket-list';

export const metadata = { title: 'Tiket Saya — STMS' };

export default function Page() {
  return <TicketList />;
}
