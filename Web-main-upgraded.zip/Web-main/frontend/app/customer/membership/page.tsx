import { MembershipPage } from '@/features/customer-portal/portal-pages';

export const metadata = { title: 'Membership — STMS' };

export default function Page() {
  return <MembershipPage />;
}
