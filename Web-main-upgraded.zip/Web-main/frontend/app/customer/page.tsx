import { CustomerDashboard } from '@/features/customer-portal/customer-dashboard';

export const metadata = { title: 'Dashboard Customer — STMS' };

export default function Page() {
  return <CustomerDashboard />;
}
