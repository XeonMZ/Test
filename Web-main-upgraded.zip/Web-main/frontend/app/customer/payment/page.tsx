import { PaymentHistory } from '@/features/customer-portal/payment-history';

export const metadata = { title: 'Pembayaran — STMS' };

export default function Page() {
  return <PaymentHistory />;
}
