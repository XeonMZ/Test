import { PromoListPage } from '@/features/customer-portal/portal-pages';

export const metadata = { title: 'Promo — STMS' };

export default function Page() {
  return <PromoListPage />;
}
