import { BookingList } from '@/features/customer-portal/booking-list';

export const metadata = { title: 'Booking Saya — STMS' };

export default function Page() {
  return <BookingList />;
}
