import { BookingDetail } from '@/features/customer-portal/booking-detail';

export const metadata = { title: 'Detail Booking — STMS' };

export default async function Page({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <BookingDetail id={id} />;
}
