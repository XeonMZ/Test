import { AdminBookingsPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Bookings — STMS' };

export default function Page() {
  return <AdminBookingsPage />;
}
