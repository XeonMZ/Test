import { AdminDriversPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Drivers — STMS' };

export default function Page() {
  return <AdminDriversPage />;
}
