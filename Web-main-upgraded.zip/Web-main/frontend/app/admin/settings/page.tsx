import { AdminSettingsPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Settings — STMS' };

export default function Page() {
  return <AdminSettingsPage />;
}
