import { AdminVehiclesPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Vehicles — STMS' };

export default function Page() {
  return <AdminVehiclesPage />;
}
