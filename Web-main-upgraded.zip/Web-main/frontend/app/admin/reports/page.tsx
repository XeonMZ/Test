import { ReportsPage } from '@/features/admin-owner/shared-pages';

export const metadata = { title: 'Laporan — STMS' };

export default function Page() {
  return <ReportsPage />;
}
