import { ProfilePage } from '@/features/admin-owner/shared-pages';

export const metadata = { title: 'Profil — STMS' };

export default function Page() {
  return <ProfilePage />;
}
