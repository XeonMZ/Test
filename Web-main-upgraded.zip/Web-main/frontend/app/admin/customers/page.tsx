import { AdminCustomersPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Customers — STMS' };

export default function Page() {
  return <AdminCustomersPage />;
}
