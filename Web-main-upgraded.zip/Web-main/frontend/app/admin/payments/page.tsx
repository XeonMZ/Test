import { AdminPaymentsPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Payments — STMS' };

export default function Page() {
  return <AdminPaymentsPage />;
}
