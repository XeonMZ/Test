import { AdminNotificationsPage } from '@/features/admin-owner/admin-console';

export const metadata = { title: 'Admin — Notifications — STMS' };

export default function Page() {
  return <AdminNotificationsPage />;
}
