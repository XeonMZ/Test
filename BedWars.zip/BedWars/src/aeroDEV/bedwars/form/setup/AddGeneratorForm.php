<?php

declare(strict_types=1);


namespace aeroDEV\bedwars\form\setup;


use dresnite\EasyUI\element\Dropdown;
use dresnite\EasyUI\element\Option;
use dresnite\EasyUI\utils\FormResponse;
use pocketmine\player\Player;
use aeroDEV\bedwars\form\CustomForm;
use aeroDEV\bedwars\game\generator\GeneratorType;
use aeroDEV\bedwars\session\Session;
use aeroDEV\bedwars\session\setup\step\AddGeneratorStep;

class AddGeneratorForm extends CustomForm {

    private Session $session;

    public function __construct(Session $session) {
        $this->session = $session;
        parent::__construct("Add generator");
    }

    protected function onCreation(): void {
        $dropdown = new Dropdown("Select the generator:");
        $dropdown->addOption(new Option(GeneratorType::DIAMOND->name, "Diamond Generator"));
        $dropdown->addOption(new Option(GeneratorType::EMERALD->name, "Emerald Generator"));

        $this->addElement("id", $dropdown);
    }

    protected function onSubmit(Player $player, FormResponse $response): void {
        $this->session->getMapSetup()->setStep(new AddGeneratorStep(
            GeneratorType::fromString($response->getDropdownSubmittedOptionId("id"))
        ));
    }

}