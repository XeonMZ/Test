<?php

declare(strict_types=1);

namespace aeroDEV\bedwars\form\shop\invmenu;

use aeroDEV\bedwars\game\shop\quickbuy\QuickBuyManager;
use aeroDEV\bedwars\session\Session;
use muqsit\invmenu\InvMenu;
use aeroDEV\bedwars\game\shop\upgrades\UpgradesShop;
use pocketmine\item\VanillaItems;
use pocketmine\utils\TextFormat;
use aeroDEV\bedwars\game\shop\item\ItemShop;
use pocketmine\world\sound\XpCollectSound;
use pocketmine\world\sound\VillagerYesSound;
use pocketmine\world\sound\VillagerNoSound;

final class InvMenuShopUI {

    // =======================
    // 🛒 ITEM SHOP (HYPIXEL STYLE)
    // =======================

    public static function openItemShop(Session $session) : void {

        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§8Item Shop");

        $inventory = $menu->getInventory();
        $productsBySlot = [];

        // 🔥 QUICK BUY DI BAWAH
        $quickSlots = [18,19,20,21,22,23,24,25,26];

        $layout = QuickBuyManager::getLayout($session);
        $lookup = self::buildItemLookup();

        // 🔥 CATEGORY DI ATAS
        $shop = new ItemShop();
        $categories = array_values($shop->getCategories());

        foreach($categories as $slot => $category){
            $icon = VanillaItems::NETHER_STAR();
            $icon->setCustomName("§a" . $category->getName());
            $inventory->setItem($slot, $icon);
        }

        // 🔥 QUICK BUY
        foreach($quickSlots as $i => $slot) {

            $productId = $layout[$i] ?? null;

            if($productId === null || !isset($lookup[$productId])) {
                $inventory->setItem(
                    $slot,
                    VanillaItems::BARRIER()->setCustomName("§7Empty Quick Buy")
                );
                continue;
            }

            $product = $lookup[$productId];

            $inventory->setItem(
                $slot,
                $product->getItem()->setCustomName($product->getDisplayName($session))
            );

            $productsBySlot[$slot] = $product;
        }

        // 🔊 CLICK LISTENER
        $menu->setListener(function($transaction) use ($session, $productsBySlot, $categories) {

            $player = $session->getPlayer();
            $slot = $transaction->getAction()->getSlot();

            // 🔥 CATEGORY CLICK (OPEN CATEGORY UI)
            if(isset($categories[$slot])){
                // nanti bisa sambung ke category menu kalau mau
                return $transaction->discard();
            }

            // 🔥 BUY ITEM
            if(isset($productsBySlot[$slot])) {

                $product = $productsBySlot[$slot];
                $success = false;

                if(method_exists($product, "buy")) {
                    $success = $product->buy($session);
                }

                if($success){
                    $player->getWorld()->addSound($player->getPosition(), new VillagerYesSound());
                }else{
                    $player->getWorld()->addSound($player->getPosition(), new VillagerNoSound());
                }
            }

            return $transaction->discard();
        });

        $menu->send($session->getPlayer());
    }

    private static function buildItemLookup(): array {
        $lookup = [];

        $shop = new ItemShop();

        foreach($shop->getCategories() as $category) {
            foreach($category->getProducts() as $product) {
                $lookup[$product->getId()] = $product;
            }
        }

        return $lookup;
    }

    // =======================
    // 🔥 UPGRADE SHOP
    // =======================

    public static function openUpgradesShop(Session $session): void {

        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§8Upgrades Shop");

        $inventory = $menu->getInventory();

        $shop = new UpgradesShop();
        $categories = array_values($shop->getCategories());

        foreach($categories as $slot => $category) {

            $icon = VanillaItems::NETHER_STAR();
            $icon->setCustomName("§b" . $category->getName());

            $inventory->setItem($slot, $icon);
        }

        $menu->setListener(function($transaction) use ($session, $categories) {

            $slot = $transaction->getAction()->getSlot();

            if(isset($categories[$slot])) {
                self::openUpgradeCategory($session, $categories[$slot]);
            }

            return $transaction->discard();
        });

        $menu->send($session->getPlayer());
    }

    // =======================
    // 🔥 CATEGORY MENU
    // =======================

    public static function openUpgradeCategory(Session $session, $category): void {

        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§8" . $category->getName());

        $inventory = $menu->getInventory();

        $products = [];
        $slot = 0;

        // 🔙 BACK BUTTON
        $back = VanillaItems::ARROW();
        $back->setCustomName("§c← Back");
        $inventory->setItem(8, $back);

        foreach($category->getProducts($session) as $product) {

            // 🔥 FIX ERROR DI SINI
            $item = clone $product->getItem(); // ⬅️ WAJIB CLONE

            $item->setCustomName($product->getDisplayName($session));

            $inventory->setItem($slot, $item);
            $products[$slot] = $product;

            $slot++;
        }

        $menu->setListener(function($transaction) use ($session, $products) {

            $player = $session->getPlayer();
            $slot = $transaction->getAction()->getSlot();

            // 🔙 BACK
            if($slot === 8){
                self::openUpgradesShop($session);
                return $transaction->discard();
            }

            if(isset($products[$slot])) {

                $product = $products[$slot];
                $success = false;

                if(method_exists($product, "buy")) {
                    $success = $product->buy($session);
                } elseif(method_exists($product, "onBuy")) {
                    $success = $product->onBuy($session);
                } elseif(method_exists($product, "onPurchase")) {
                    $success = $product->onPurchase($session);
                }

                // 🔊 SOUND SYSTEM FINAL
                if($success){
                    $player->getWorld()->addSound($player->getPosition(), new XpCollectSound());
                    $player->getWorld()->addSound($player->getPosition(), new VillagerYesSound());
                }else{
                    $player->getWorld()->addSound($player->getPosition(), new VillagerNoSound());
                }
            }

            return $transaction->discard();
        });

        $menu->send($session->getPlayer());
    }
}