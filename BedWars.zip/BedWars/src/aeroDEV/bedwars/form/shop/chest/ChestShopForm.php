<?php

declare(strict_types=1);

namespace aeroDEV\bedwars\form\shop\chest;

use aeroDEV\bedwars\form\shop\ShopForm;
use aeroDEV\bedwars\game\shop\Shop;
use aeroDEV\bedwars\session\Session;

class ChestShopForm extends ShopForm {

    public function __construct(Session $session, string $name, Shop $shop) {
        parent::__construct($session, "Chest UI - " . $name, $shop);
    }
}
