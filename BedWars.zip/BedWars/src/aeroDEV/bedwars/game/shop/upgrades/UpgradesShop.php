<?php

declare(strict_types=1);

namespace aeroDEV\bedwars\game\shop\upgrades;

use aeroDEV\bedwars\game\shop\Shop;
use aeroDEV\bedwars\game\shop\ShopCategory;
use aeroDEV\bedwars\game\shop\upgrades\product\UpgradeProduct;
use aeroDEV\bedwars\game\shop\upgrades\product\TrapProduct;
use pocketmine\item\VanillaItems;

class UpgradesShop extends Shop {

    public function getName(): string {
        return "Upgrades";
    }

    /**
     * @return ShopCategory[]
     */
    public function getCategories(): array {

        $categories = [];

        // =========================
        // ⚔️ TEAM UPGRADES
        // =========================
        $team = new ShopCategory("Team Upgrades");

        $team->addProduct(new UpgradeProduct("Haste", 2, VanillaItems::IRON_PICKAXE()));
        $team->addProduct(new UpgradeProduct("Protection", 2, VanillaItems::IRON_CHESTPLATE()));
        $team->addProduct(new UpgradeProduct("Sharpness", 4, VanillaItems::IRON_SWORD()));
        $team->addProduct(new UpgradeProduct("Forge", 2, VanillaItems::FURNACE()));

        $categories[] = $team;

        // =========================
        // 🪤 TRAPS
        // =========================
        $traps = new ShopCategory("Traps");

        $traps->addProduct(new TrapProduct("Alarm Trap", 1, VanillaItems::TRIPWIRE_HOOK()));
        $traps->addProduct(new TrapProduct("Mining Fatigue", 1, VanillaItems::IRON_PICKAXE()));
        $traps->addProduct(new TrapProduct("Blindness Trap", 1, VanillaItems::ENDER_EYE()));
        $traps->addProduct(new TrapProduct("Counter-Offensive", 1, VanillaItems::BLAZE_POWDER()));

        $categories[] = $traps;

        return $categories;
    }
}