<?php

declare(strict_types=1);

namespace aeroDEV\bedwars\game\team\upgrade;

use aeroDEV\bedwars\session\Session;

abstract class Upgrade {

    protected int $level = 0;

    abstract public function getName(): string;

    abstract public function getLevels(): int;

    // 🔥 TAMBAHKAN INI
    public function applySession(Session $session): void {
        $this->internalApplySession($session);
    }

    // 🔥 TAMBAHKAN INI JUGA
    abstract protected function internalApplySession(Session $session): void;

    public function getLevel(): int {
        return $this->level;
    }

    public function canBeUpgraded(): bool {
        return $this->level < $this->getLevels();
    }

    public function upgrade(): bool {
        if(!$this->canBeUpgraded()) {
            return false;
        }

        ++$this->level;
        return true;
    }
}