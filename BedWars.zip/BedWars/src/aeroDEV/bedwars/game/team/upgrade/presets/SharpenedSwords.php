<?php

declare(strict_types=1);


namespace aeroDEV\bedwars\game\team\upgrade\presets;


use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Sword;
use aeroDEV\bedwars\game\team\upgrade\Upgrade;
use aeroDEV\bedwars\session\Session;

class SharpenedSwords extends Upgrade {

    protected function internalApplySession(Session $session): void {
    $this->apply($session);
}

// fungsi lama (biarkan)
public function apply(Session $session): void {
    $inventory = $session->getPlayer()->getInventory();

    foreach($inventory->getContents() as $slot => $item) {
        if($item instanceof \pocketmine\item\Sword) {
            $item->addEnchantment(
                new \pocketmine\item\enchantment\EnchantmentInstance(
                    \pocketmine\item\enchantment\VanillaEnchantments::SHARPNESS(), 1
                )
            );
            $inventory->setItem($slot, $item);
        }
    }
}