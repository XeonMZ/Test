<?php

declare(strict_types=1);


namespace aeroDEV\bedwars\game\team\upgrade\presets;


use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\utils\Limits;
use aeroDEV\bedwars\game\team\upgrade\Upgrade;
use aeroDEV\bedwars\session\Session;

class ManiacMiner extends Upgrade {

    public function getName(): string {
        return "Maniac Miner";
    }

    public function getLevels(): int {
        return 2;
    }

    protected function internalApplySession(Session $session): void {
    $this->apply($session);
}

// fungsi lama
public function apply(Session $session): void {
    $session->getPlayer()->getEffects()->add(
        new \pocketmine\entity\effect\EffectInstance(
            \pocketmine\entity\effect\VanillaEffects::HASTE(),
            999999,
            $this->level - 1,
            false
        )
    );
}
    }