<?php

declare(strict_types=1);

namespace App\Events;

use App\Models\User;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

final class ProfileUpdated
{
    use Dispatchable, SerializesModels;

    public function __construct(public readonly User $user, public readonly array $metadata = []) {}
}
