<?php

$betaMode = (bool) env('STMS_BETA_MODE', true) && env('APP_ENV') !== 'production';

return [
    'default' => $betaMode ? 'log' : env('BROADCAST_CONNECTION', 'log'),
    'connections' => [
        'reverb' => [
            'driver' => 'reverb',
            'key' => env('REVERB_APP_KEY', ''),
            'secret' => env('REVERB_APP_SECRET', ''),
            'app_id' => env('REVERB_APP_ID', ''),
            'options' => [
                'host' => env('REVERB_HOST', 'localhost'),
                'port' => env('REVERB_PORT', 443),
                'scheme' => env('REVERB_SCHEME', 'https'),
                'useTLS' => env('REVERB_SCHEME', 'https') === 'https',
            ],
        ],
        'redis' => ['driver' => 'redis', 'connection' => 'default'],
        'log' => ['driver' => 'log'],
        'null' => ['driver' => 'null'],
    ],
];
