<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('system_settings', function (Blueprint $table): void { $table->uuid('uuid')->nullable()->unique()->after('id'); $table->softDeletes(); });
        Schema::table('feature_flags', function (Blueprint $table): void { $table->uuid('uuid')->nullable()->unique()->after('id'); $table->softDeletes(); });
    }
    public function down(): void
    {
        Schema::table('feature_flags', function (Blueprint $table): void { $table->dropSoftDeletes(); $table->dropColumn('uuid'); });
        Schema::table('system_settings', function (Blueprint $table): void { $table->dropSoftDeletes(); $table->dropColumn('uuid'); });
    }
};
