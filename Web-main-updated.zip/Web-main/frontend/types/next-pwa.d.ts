declare module 'next-pwa';
